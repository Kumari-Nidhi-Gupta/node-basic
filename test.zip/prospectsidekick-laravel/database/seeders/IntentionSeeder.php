<?php

namespace Database\Seeders;

use App\Models\Intention;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class IntentionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('intentions')->truncate();
        $valueArray = ["Set a time to follow up", "Set an appointment", "Handle an objection",
                       "Answer a question", "Gather information", "Build rapport",    "Address concerns proactively",
                       "Ask open-ended questions",
                       "Close the sale",
                       "Collaborate on problem-solving",
                       "Collaborate with internal teams",
                       "Conduct market research",
                       "Create a sense of urgency",
                       "Develop a long-term relationship",
                       "Develop a personal brand",
                       "Develop a tailored pitch",
                       "Discuss pricing",
                       "Educate the prospect",
                       "Emphasize value",
                       "Engage in active listening",
                       "Establish expertise",
                       "Establish a post-sale follow-up process",
                       "Foster a positive company image",
                       "Follow up",
                       "Gather feedback",
                       "Identify needs",
                       "Involve stakeholders",
                       "Keep track of sales metrics",
                       "Leverage networking opportunities",
                       "Leverage social proof",
                       "Leverage technology",
                       "Maintain communication",
                       "Manage expectations",
                       "Negotiate terms",
                       "Offer a trial or sample",
                       "Offer flexible payment options",
                       "Offer guarantees or warranties",
                       "Offer ongoing support",
                       "Overcome competition",
                       "Present a solution",
                       "Promote special promotions or discounts",
                       "Provide product demonstration",
                       "Qualify the prospect",
                       "Recognize buying signals",
                       "Request feedback after rejection",
                       "Share testimonials",
                       "Upsell or cross-sell",
                       "Use data-driven insights",
                       "Use storytelling",
                       "Utilize sales enablement tools"];
        $records = [];
        foreach ($valueArray as $key => $value) {
            $records[] = [
                'name' => $value
            ];
        }
        Intention::insert($records);
    }
}
