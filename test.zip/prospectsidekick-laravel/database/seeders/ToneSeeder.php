<?php

namespace Database\Seeders;

use App\Models\Tone;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ToneSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('tones')->truncate();
        $valueArray = ["Professional", "Enthusiastic", "Persuasive", "Empathetic", "Confident",
        "Straightforward", "Casual", "Relatable", "Educational", "Formal", "Amicable", "Enthusiastic", "Confident", "Humble", "Polite", "Respectful", "Informative", "Persuasive", "Empathetic", "Patient", "Trustworthy", "Energetic", "Positive", "Warm", "Courteous", "Assertive", "Calm", "Professional", "Encouraging", "Reassuring", "Sincere", "Honest", "Adaptable", "Attentive", "Genuine", "Helpful", "Inquisitive", "Approachable", "Caring", "Knowledgeable", "Tactful", "Solution-focused", "Collaborative", "Composed", "Direct", "Diplomatic", "Passionate", "Motivated", "Inspiring", "Engaging", "Relatable", "Lighthearted", "Casual", "Congenial", "Vivacious", "Focused", "Gracious", "Convincing", "Responsive", "Supportive", "Agreeable", "Tenacious", "Sympathetic", "Nonchalant", "Animated", "Pleasant", "Charismatic", "Open-minded", "Thoughtful", "Active listening", "Complimentary", "Explanatory", "Appreciative", "Balanced", "Genuine curiosity", "Discreet", "Empowering", "Understanding", "Mindful", "Clear", "Firm", "Authentic", "Optimistic", "Proactive", "Respectful curiosity", "Imaginative", "Strategic", "Accountable", "Detail-oriented", "Decisive", "Serene", "Analytical", "Unassuming", "Gentle", "Efficient", "Discerning", "Realistic", "Concise", "Perceptive", "Solution-oriented", "Cooperative", "Inviting", "Poised", "Transparent", "Resourceful", "Dynamic", "Steadfast", "Deliberate", "Observant", "Accommodating" ];
        $records = [];
        foreach ($valueArray as $key => $value) {
            $records[] = [
                'name' => $value
            ];
        }
        Tone::insert($records);
    }
}
