<div class="card border-0 shadow-sm rounded-4">
    <div class="card-body">
        <ul class="list list-row gy-0 g-1 mb-3">
            <li><em class="icon text-warning ni ni-star-fill fs-5"></em></li>
            <li><em class="icon text-warning ni ni-star-fill fs-5"></em></li>
            <li><em class="icon text-warning ni ni-star-fill fs-5"></em></li>
            <li><em class="icon text-warning ni ni-star-fill fs-5"></em></li>
            <li><em class="icon text-warning ni ni-star-fill fs-5"></em></li>
        </ul>
        <h4 class="title mb-3">The best chatgpt alternative so far if you're restricted from their chatgpt plus subscription.</h4>
        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
            doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore
            veritatis</p>
        <div class="d-flex pt-3">
            <div class="media media-lg media-middle media-lg rounded-pill"><img
                    src="{{asset('assets/V2/images/')}}/avatar/author/sm-b.jpg" alt="">
            </div>
            <div class="media-info ms-3">
                <h5 class="mb-1">Khan Mujtaba</h5>
                <div class="sub-text">CEO at Clickable Man</div>
            </div>
        </div>
    </div>
</div>
