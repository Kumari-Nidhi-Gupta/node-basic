{!! file_get_contents($receipt_url) !!}
