{{auth()->user()->first_name." ".auth()->user()->last_name}}
