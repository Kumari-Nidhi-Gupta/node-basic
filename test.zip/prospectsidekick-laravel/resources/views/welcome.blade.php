@extends('layouts.homepage')
@section('content')
    @component('layouts.partial.header')
        @slot('banner')
            @include('landing.banner')
        @endslot
    @endcomponent
    {{--<style>

        :root {
            --white: white;
            --gray: #999;
            --lightgray: whitesmoke;
            --darkgreen: #2a9d8f;
            --popular: #ffdd40;
            --starter: #f73859;
            --essential: #00aeef;
            --professional: #ff7f45;
        }

        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

    </style>--}}
    <!-- Page content -->
    {{--<main class="rm">

        <!-- Hero -->
        <section class="b im">

            <!-- Bg gradient -->
            <div class="y w x k su sc sm as nm v te" aria-hidden="true"></div>

            <!-- Illustration -->
            <div class="y _ rg v te" aria-hidden="true">
                <img src="{{asset('assets/{{asset('assets/V2/images/')}}/hero-illustration.svg')}}" class="ri" width="2143" height="737"
                     alt="Hero Illustration">
            </div>

            <div class="b rr tf ot ld">
                <div class="ov om ch cp">

                    <!-- Hero content -->
                    <div class="rs tf lk ly ox cv">

                        <div data-aos="zoom-out" class="aos-init aos-animate">
                            <div class="b oj um sr ig na ot oi td ft ad am av ag a_ aj fe aq ax">
                                <div class="up">Add to Chrome. <a class="ui ug nc ie al ah ap fj" href="#">Install Extension <span class="uc fq ac ah ap tp">-&gt;</span></a></div>
                            </div>
                        </div>
                        <h1 class="h1 o_ td aos-init aos-animate" data-aos="zoom-out" data-aos-delay="100">Your AI
                            powered <em class="font-italic">Helper</em></h1>
                        <p class="oq up tv aos-init aos-animate" data-aos="zoom-out" data-aos-delay="200">Prospect Sidekick
                            is a browser extension that enhance search engines with the power of ChatGPT. It
                            works by showing ChatGPT response alongside normal search engine results.</p>
                        <div class="ro tf lo li lf cs if lh lp aos-init aos-animate" data-aos="zoom-out"
                             data-aos-delay="300">
                            <div>
                                <a class="n ud su sl sv fr nj ao fj" href="#">
                                    Get Started For Free <span class="uc uv fq ac ah ap tp">-&gt;</span>
                                </a>
                            </div>
                            <div>
                                <a class="n um su sc sg fi nj ao" href="#">Explore Tutorials</a>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </section>
        <!-- Features -->
        <section>
            <div class="rr tf ot ld">
                <div class="oo ca">

                    <!-- Section header -->
                    <div class="ox om cp">
                        <h3 class="h2 o_ aos-init aos-animate" data-aos="zoom-out">Just Highlight The Message You're Responding To And Let Prospect Sidekick Do The Work</h3>
                    </div>

                    <div class="og aos-init aos-animate" data-aos="zoom-out">
                        <img src="{{asset('assets/{{asset('assets/V2/images/')}}/hero.png')}}" width="1104" height="512"
                             alt="Features">
                    </div>

                    <!-- Items -->
                    <div class="ru tf nh io ce he rz lj">

                        <!-- 1st item -->
                        <div class="nl rj ie aos-init aos-animate" data-aos="zoom-out">
                            <div class="tm">
                                <svg width="56" height="56" xmlns="http://www.w3.org/2000/svg"
                                     xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <defs>
                                        <radialgradient cx="50%" cy="89.845%" fx="50%" fy="89.845%" r="89.85%"
                                                        id="icon1-b">
                                            <stop stop-color="#3B82F6" stop-opacity=".64" offset="0%"></stop>
                                            <stop stop-color="#F472B6" stop-opacity=".876" offset="100%"></stop>
                                        </radialgradient>
                                        <circle id="icon1-a" cx="28" cy="28" r="28"></circle>
                                    </defs>
                                    <g fill="none" fill-rule="evenodd">
                                        <use fill="url(#icon1-b)" xlink:href="#icon1-a"></use>
                                        <g stroke="#FDF2F8" stroke-linecap="square" stroke-width="2">
                                            <path d="M17 28h22" opacity=".64"></path>
                                            <path d="M20 23v-3h3M33 20h3v3M36 33v3h-3M23 36h-3v-3"></path>
                                        </g>
                                    </g>
                                </svg>
                            </div>
                            <h4 class="h4 uy ox tg">Select a text</h4>
                            <p class="oz up ox">Just highlight any text on the page and open the Prospect Extension.</p>
                        </div>

                        <!-- 2nd item -->
                        <div class="nl rj ie aos-init aos-animate" data-aos="zoom-out" data-aos-delay="200">
                            <div class="tm">
                                <svg width="56" height="56" xmlns="http://www.w3.org/2000/svg"
                                     xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <defs>
                                        <radialgradient cx="50%" cy="89.845%" fx="50%" fy="89.845%" r="89.85%"
                                                        id="icon2-b">
                                            <stop stop-color="#3B82F6" stop-opacity=".64" offset="0%"></stop>
                                            <stop stop-color="#F472B6" stop-opacity=".876" offset="100%"></stop>
                                        </radialgradient>
                                        <circle id="icon2-a" cx="28" cy="28" r="28"></circle>
                                    </defs>
                                    <g fill="none" fill-rule="evenodd">
                                        <use fill="url(#icon2-b)" xlink:href="#icon2-a"></use>
                                        <g stroke="#FDF2F8" stroke-linecap="square" stroke-width="2">
                                            <path d="m22 24-4 4 4 4M34 24l4 4-4 4"></path>
                                            <path d="m26 36 4-16" opacity=".64"></path>
                                        </g>
                                    </g>
                                </svg>
                            </div>
                            <h4 class="h4 uy ox tg">Get Response in Seconds</h4>
                            <p class="oz up ox">A Response will be generated based on your query and shared in
                                seconds.</p>
                        </div>

                        <!-- 3rd item -->
                        <div class="nl rj ie aos-init aos-animate" data-aos="zoom-out" data-aos-delay="400">
                            <div class="tm">
                                <svg width="56" height="56" xmlns="http://www.w3.org/2000/svg"
                                     xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <defs>
                                        <radialgradient cx="50%" cy="89.845%" fx="50%" fy="89.845%" r="89.85%"
                                                        id="icon3-b">
                                            <stop stop-color="#3B82F6" stop-opacity=".64" offset="0%"></stop>
                                            <stop stop-color="#F472B6" stop-opacity=".876" offset="100%"></stop>
                                        </radialgradient>
                                        <circle id="icon3-a" cx="28" cy="28" r="28"></circle>
                                    </defs>
                                    <g fill="none" fill-rule="evenodd">
                                        <use fill="url(#icon3-b)" xlink:href="#icon3-a"></use>
                                        <g stroke="#FDF2F8" stroke-linecap="square" stroke-width="2">
                                            <path d="m18 31 4 4 12-15"></path>
                                            <path d="M39 25h-3M39 30h-7M39 35H28" opacity=".64"></path>
                                        </g>
                                    </g>
                                </svg>
                            </div>
                            <h4 class="h4 uy ox tg">Make Changes/Updates</h4>
                            <p class="oz up ox">Use the update input to request any changes on the response
                                provided.</p>
                        </div>

                    </div>

                </div>
            </div>
        </section>
        <!-- Pricing -->
    @include("share.plans", ["show_title" => true])

    <!-- Testimonials -->
        <section class="b">

            <!-- Bg gradient: top -->
            <div class="y j x k sa sc sm as nm v te" aria-hidden="true"></div>

            <!-- Bg gradient: bottom -->
            <div class="y w x k su sh sy nb v tt" aria-hidden="true"></div>

            <div class="rr tf ot ld">
                <div class="ob cd">

                    <!-- Section header -->
                    <div class="rf tf ox om cp">
                        <h2 class="h2 o_">What Our Customers are Saying</h2>
                    </div>

                    <!-- Testimonials container -->
                    <div class="ru tf lo nh iu lu ce ll lc rz" data-aos-id-testimonials="">

                        <article class="ny nl rj sr oe aos-init aos-animate" data-aos="fade"
                                 data-aos-anchor="[data-aos-id-testimonials]" data-aos-delay="400">
                            <header class="tm">
                                <img class="ig rv" src="{{ asset('assets/{{asset('assets/V2/images/')}}/profile.png') }}"
                                     width="48" height="48" alt="Testimonial 05">
                            </header>
                            <div class="rm tj">
                                <p class="up">The best chatgpt alternative so far if you're restricted from their
                                    chatgpt plus subscription.</p>
                            </div>
                            <footer class="oj up">
                                <span class="um">Khan Mujtaba </span> - <a class="ui ug fu al ah ap" href="#">
                                    Clickable Man</a>
                            </footer>
                        </article>
                        <article class="ny nl rj sr oe aos-init aos-animate" data-aos="fade"
                                 data-aos-anchor="[data-aos-id-testimonials]" data-aos-delay="400">
                            <header class="tm">
                                <img class="ig rv" src="{{ asset('assets/{{asset('assets/V2/images/')}}/profile.png') }}"
                                     width="48" height="48" alt="Testimonial 05">
                            </header>
                            <div class="rm tj">
                                <p class="up">The best chatgpt alternative so far if you're restricted from their
                                    chatgpt plus subscription.</p>
                            </div>
                            <footer class="oj up">
                                <span class="um">Khan Mujtaba </span> - <a class="ui ug fu al ah ap" href="#">
                                    Clickable Man</a>
                            </footer>
                        </article>

                        <article class="ny nl rj sr oe aos-init aos-animate" data-aos="fade"
                                 data-aos-anchor="[data-aos-id-testimonials]" data-aos-delay="400">
                            <header class="tm">
                                <img class="ig rv" src="{{ asset('assets/{{asset('assets/V2/images/')}}/profile.png') }}"
                                     width="48" height="48" alt="Testimonial 05">
                            </header>
                            <div class="rm tj">
                                <p class="up">The best chatgpt alternative so far if you're restricted from their
                                    chatgpt plus subscription.</p>
                            </div>
                            <footer class="oj up">
                                <span class="um">Khan Mujtaba </span> - <a class="ui ug fu al ah ap" href="#">
                                    Clickable Man</a>
                            </footer>
                        </article>
                        <article class="ny nl rj sr oe aos-init aos-animate" data-aos="fade"
                                 data-aos-anchor="[data-aos-id-testimonials]" data-aos-delay="400">
                            <header class="tm">
                                <img class="ig rv" src="{{ asset('assets/{{asset('assets/V2/images/')}}/profile.png') }}"
                                     width="48" height="48" alt="Testimonial 05">
                            </header>
                            <div class="rm tj">
                                <p class="up">The best chatgpt alternative so far if you're restricted from their
                                    chatgpt plus subscription.</p>
                            </div>
                            <footer class="oj up">
                                <span class="um">Khan Mujtaba </span> - <a class="ui ug fu al ah ap" href="#">
                                    Clickable Man</a>
                            </footer>
                        </article>

                        <article class="ny nl rj sr oe aos-init aos-animate" data-aos="fade"
                                 data-aos-anchor="[data-aos-id-testimonials]" data-aos-delay="400">
                            <header class="tm">
                                <img class="ig rv" src="{{ asset('assets/{{asset('assets/V2/images/')}}/profile.png') }}"
                                     width="48" height="48" alt="Testimonial 05">
                            </header>
                            <div class="rm tj">
                                <p class="up">The best chatgpt alternative so far if you're restricted from their
                                    chatgpt plus subscription.</p>
                            </div>
                            <footer class="oj up">
                                <span class="um">Khan Mujtaba </span> - <a class="ui ug fu al ah ap" href="#">
                                    Clickable Man</a>
                            </footer>
                        </article>

                        <article class="ny nl rj sr oe aos-init aos-animate" data-aos="fade"
                                 data-aos-anchor="[data-aos-id-testimonials]" data-aos-delay="400">
                            <header class="tm">
                                <img class="ig rv" src="{{ asset('assets/{{asset('assets/V2/images/')}}/profile.png') }}"
                                     width="48" height="48" alt="Testimonial 05">
                            </header>
                            <div class="rm tj">
                                <p class="up">The best chatgpt alternative so far if you're restricted from their
                                    chatgpt plus subscription.</p>
                            </div>
                            <footer class="oj up">
                                <span class="um">Khan Mujtaba </span> - <a class="ui ug fu al ah ap" href="#">
                                    Clickable Man</a>
                            </footer>
                        </article>

                        <article class="ny nl rj sr oe aos-init aos-animate" data-aos="fade"
                                 data-aos-anchor="[data-aos-id-testimonials]" data-aos-delay="400">
                            <header class="tm">
                                <img class="ig rv" src="{{ asset('assets/{{asset('assets/V2/images/')}}/profile.png') }}"
                                     width="48" height="48" alt="Testimonial 05">
                            </header>
                            <div class="rm tj">
                                <p class="up">The best chatgpt alternative so far if you're restricted from their
                                    chatgpt plus subscription.</p>
                            </div>
                            <footer class="oj up">
                                <span class="um">Khan Mujtaba </span> - <a class="ui ug fu al ah ap" href="#">
                                    Clickable Man</a>
                            </footer>
                        </article>

                        <article class="ny nl rj sr oe aos-init aos-animate" data-aos="fade"
                                 data-aos-anchor="[data-aos-id-testimonials]" data-aos-delay="400">
                            <header class="tm">
                                <img class="ig rv" src="{{ asset('assets/{{asset('assets/V2/images/')}}/profile.png') }}"
                                     width="48" height="48" alt="Testimonial 05">
                            </header>
                            <div class="rm tj">
                                <p class="up">The best chatgpt alternative so far if you're restricted from their
                                    chatgpt plus subscription.</p>
                            </div>
                            <footer class="oj up">
                                <span class="um">Khan Mujtaba </span> - <a class="ui ug fu al ah ap" href="#">
                                    Clickable Man</a>
                            </footer>
                        </article>

                        <article class="ny nl rj sr oe aos-init aos-animate" data-aos="fade"
                                 data-aos-anchor="[data-aos-id-testimonials]" data-aos-delay="400">
                            <header class="tm">
                                <img class="ig rv" src="{{ asset('assets/{{asset('assets/V2/images/')}}/profile.png') }}"
                                     width="48" height="48" alt="Testimonial 05">
                            </header>
                            <div class="rm tj">
                                <p class="up">The best chatgpt alternative so far if you're restricted from their
                                    chatgpt plus subscription.</p>
                            </div>
                            <footer class="oj up">
                                <span class="um">Khan Mujtaba </span> - <a class="ui ug fu al ah ap" href="#">
                                    Clickable Man</a>
                            </footer>
                        </article>


                    </div>

                </div>
            </div>

        </section>

        <!-- Resources -->
        <section>
            <div class="rr tf ot ld">
                <div class="oo ca">

                    <!-- Section header -->
                    <div class="rf tf ox om cp">
                        <h2 class="h2 o_">Other available resources</h2>
                    </div>

                    <!-- Boxes -->
                    <div class="ru tf lo nh iu lu ct ll lc rz">

                        <!-- 1st Box -->
                        <a class="nu b ft ak ad am av oe fj" href="#"
                           x-show="[&#39;1&#39;, &#39;3&#39;, &#39;4&#39;].includes(category)" style="">
                            <div class="b nw re ig su sc sg nl ie ir ao tj ft ad am av ag a_ aj fe aq ax">
                                <img src="{{asset('assets/{{asset('assets/V2/images/')}}/chrome.svg')}}">
                            </div>
                            <div class="o_ oq uh us">Prospect Sidekick Chrome</div>
                        </a>

                        <!-- 2nd Box -->
                        <a class="nu b ft ak ad am av oe fj" href="#"
                           x-show="[&#39;2&#39;, &#39;3&#39;].includes(category)" style="display: none;">
                            <div class="b nw re ig su sc sg nl ie ir ao tj ft ad am av ag a_ aj fe aq ax">
                                <svg class="sz le al ah ap" width="24" height="18"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M20.317 1.492c-1.53-.69-3.17-1.2-4.885-1.49a.075.075 0 0 0-.079.036c-.21.369-.444.85-.608 1.23a18.565 18.565 0 0 0-5.487 0C9.095.88 8.852.406 8.641.037A.077.077 0 0 0 8.562 0c-1.714.29-3.354.8-4.885 1.491a.07.07 0 0 0-.032.027C.533 6.093-.32 10.555.099 14.961a.08.08 0 0 0 .031.055 20.03 20.03 0 0 0 5.993 2.98.078.078 0 0 0 .084-.026c.462-.62.874-1.275 1.226-1.963.021-.04.001-.088-.041-.104a13.202 13.202 0 0 1-1.872-.878.075.075 0 0 1-.008-.125c.126-.093.252-.19.372-.287a.075.075 0 0 1 .078-.01c3.927 1.764 8.18 1.764 12.061 0a.075.075 0 0 1 .078.009c.12.097.246.195.373.288a.075.075 0 0 1-.006.125c-.598.344-1.22.635-1.873.877a.075.075 0 0 0-.041.105c.36.687.772 1.341 1.225 1.962a.077.077 0 0 0 .084.028 19.964 19.964 0 0 0 6.002-2.981.076.076 0 0 0 .032-.054c.5-5.094-.839-9.52-3.549-13.442a.06.06 0 0 0-.031-.028ZM8.02 12.278c-1.183 0-2.157-1.068-2.157-2.38 0-1.312.956-2.38 2.157-2.38 1.21 0 2.176 1.077 2.157 2.38 0 1.312-.956 2.38-2.157 2.38Zm7.975 0c-1.183 0-2.157-1.068-2.157-2.38 0-1.312.955-2.38 2.157-2.38 1.21 0 2.176 1.077 2.157 2.38 0 1.312-.946 2.38-2.157 2.38Z"
                                        fill-rule="nonzero"></path>
                                </svg>
                            </div>
                            <div class="o_ oq uh us">Prospect Sidekick Firefox</div>
                        </a>

                        <!-- 3rd Box -->
                        <a class="nu b ft ak ad am av oe fj" href="#">
                            <div class="b nw re ig su sc sg nl ie ir ao tj ft ad am av ag a_ aj fe aq ax">
                                <img src="{{asset('assets/{{asset('assets/V2/images/')}}/firefox.svg.png')}}" alt="">
                            </div>
                            <div class="o_ oq uh us">Prospect Sidekick Firefox</div>
                        </a>

                        <a class="nu b ft ak ad am av oe fj" href="#">
                            <div class="b nw re ig su sc sg nl ie ir ao tj ft ad am av ag a_ aj fe aq ax">
                                <svg class="sz le al ah ap" width="23" height="23"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M4.924 19h6.927l5.128 1.386 3.399-12.548L16 6.654V4.582l5.859 1.586a1 1 0 0 1 .704 1.226l-3.913 14.48a1 1 0 0 1-1.226.705l-12.55-3.393.05-.186Z"
                                        fill-rule="nonzero" fill-opacity=".64"></path>
                                    <rect width="14" height="17" rx="1"></rect>
                                </svg>
                            </div>
                            <div class="o_ oq uh us">Prospect Sidekick Docs</div>
                        </a>

                        <a class="nu b ft ak ad am av oe fj" href="h#">
                            <div class="b nw re ig su sc sg nl ie ir ao tj ft ad am av ag a_ aj fe aq ax">
                                <svg class="sz le al ah ap" width="22" height="18"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M21.083 0H.917C.41 0 0 .448 0 1v16c0 .552.41 1 .917 1h20.166c.507 0 .917-.448.917-1V1c0-.552-.41-1-.917-1ZM9 13V5l6 4-6 4Z"
                                        fill-rule="nonzero"></path>
                                </svg>
                            </div>
                            <div class="o_ oq uh us">Prospect Sidekick Tutorials</div>
                        </a>

                    </div>

                </div>
            </div>

        </section>

        <!-- CTA -->
        <section>
            <div class="rr tf ot ld">

                <!-- CTA box -->
                <div class="b sf sl sb iy oa of cf cl im aos-init aos-animate" data-aos="zoom-out">

                    <!-- Bg illustration -->
                    <div class="np cx y k q ry tz te" aria-hidden="true">
                        <img src="{{assert('assets/{{asset('assets/V2/images/')}}/cta-illustration.svg')}}" class="ri" width="582"
                             height="662" alt="Illustration">
                    </div>

                    <div class="nl rj cz ii ie">

                        <!-- CTA content -->
                        <div class="td cb cw ox hi">
                            <h3 class="ue uo o_ tg">Get started with Prospect Sidekick</h3>
                            <p class="uv">It only takes a few minutes to get started with Prospect Sidekick. Understand your
                                needs, start free, today.</p>
                        </div>

                        <!-- CTA button -->
                        <div class="rv">
                            <a class="r ud su sl sv fr nj fj ao" href="#">
                                Add to Chrome <span class="uc uv fq ac ah ap tp">-&gt;</span>
                            </a>
                        </div>

                    </div>

                </div>

            </div>
        </section>

    </main>--}}
    <main class="nk-pages">
            <section class="section section-bottom-0">
               <div class="container">
                  <div class="section-head">
                     <div class="row justify-content-center text-center">
                        <div class="col-lg-8 col-xl-7 col-xxl-6">
                           <!-- <h6 class="overline-title text-primary">How it works</h6> -->
                           <h2 class="title">Just Highlight The Message You're Responding To And Let Prospect Sidekick Do The Work
                        </h2>
                        </div>
                     </div>
                  </div>
                  <div class="section-content">
                     <div class="row g-gs justify-content-center flex-md-row-reverse align-items-center">
                        <div class="col-xl-4 col-lg-5 col-md-6">
                           <div class="rounded-4 bg-info bg-opacity-50 p-5 pe-0">
                              <div class="block-gfx me-n4"><img class="w-100 rounded-3 shadow-sm" src="https://prospectsidekick.tech/004.gif" alt=""></div>
                           </div>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-6">
                           <div class="block-text">
                              <div class="media media-middle text-bg-primary-soft rounded-pill fw-medium fs-5 mb-3">01</div>
                              <h3 class="title">Select a text
                            </h3>
                              <p>Just highlight the client's message and click on the Prospect Sidekick icon.

                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="sction-sap text-center py-3 d-none d-md-block">
                     <svg class="h-3rem h-sm-5rem h-lg-7rem" viewBox="0 0 444 112" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M442.989 1C443.49 18.4197 426.571 53.2592 354.892 53.2591C265.293 53.2591 126.139 53.2591 80.0875 53.2591C34.0366 53.2591 7.00663 85.784 0.999979 111" stroke="currentColor" stroke-dasharray="7 7" />
                     </svg>
                  </div>
                  <div class="h-3rem d-md-none"></div>
                  <div class="section-content">
                     <div class="row g-gs justify-content-center align-items-center">
                        <div class="col-xl-4 col-lg-5 col-md-6">
                           <div class="rounded-4 bg-primary bg-opacity-40 p-5 ps-0">
                              <div class="block-gfx ms-n4"><img class="w-100 rounded-3 shadow-sm" src="https://prospectsidekick.tech/003.gif" alt=""></div>
                           </div>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-6">
                           <div class="block-text px-xxl-5">
                              <div class="media media-middle text-bg-primary-soft rounded-pill fw-medium fs-5 mb-3">02</div>
                              <h3 class="title">Select Your Desired Presets
                            </h3>
                              <p>Choose what you want the tone to be for your response, what the intention of the response is, how long you want the response to be, if you're responding to an SMS or email, and if you want to complete your response with a question or a statement.</p>
                              <!-- <ul class="list gy-2">
                                 <li><em class="icon ni ni-dot"></em><span>At vero eos et accusamus et iusto</span></li>
                                 <li><em class="icon ni ni-dot"></em><span>At vero eos et accusamus et iusto</span></li>
                              </ul> -->
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="sction-sap text-center py-3 d-none d-md-block">
                     <svg class="h-3rem h-sm-5rem h-lg-7rem" viewBox="0 0 444 114" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1.01068 1C0.510125 18.7364 17.4289 54.2093 89.1082 54.2093C178.707 54.2093 317.861 54.2093 363.912 54.2093C409.963 54.2093 436.993 87.3256 443 113" stroke="currentColor" stroke-dasharray="7 7" />
                     </svg>
                  </div>
                  <div class="h-3rem d-md-none"></div>
                  <div class="section-content">
                     <div class="row g-gs justify-content-center flex-md-row-reverse align-items-center">
                        <div class="col-xl-4 col-lg-5 col-md-6">
                           <div class="rounded-4 bg-pink bg-opacity-30 p-5 pe-0">
                              <div class="block-gfx me-n4"><img class="w-100 rounded-3 shadow-sm" src="https://prospectsidekick.tech/002.gif" alt=""></div>
                           </div>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-6">
                           <div class="block-text">
                              <div class="media media-middle text-bg-primary-soft rounded-pill fw-medium fs-5 mb-3">03</div>
                              <h3 class="title">Get Response in Seconds
                            </h3>
                              <p>Add additional context to direct your responses, press enter, copy to clipboard and send!

                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
             <section class="section section-lg section-bottom-0">
                <div class="container">
                   <div class="section-head">
                      <div class="row justify-content-center text-center">
                         <div class="col-lg-9 col-xl-8 col-xxl-7">
                            <h2 class="title h1">What Our Customers are Saying                            </h2>
                         </div>
                      </div>
                   </div>
                   <div class="section-content">
                      <div class="row g-gs">
                         <div class="col-md-6 col-xl-4">
                            <div class="card rounded-4 border-0 shadow-sm h-100">
                               <div class="card-body">
                                  <div class="feature">
                                   
                                        <blockquote class="twitter-tweet" data-theme="dark"><p lang="en" dir="ltr">This app makes life so much easier!! 10/10 highly recommend <a href="https://twitter.com/prospect_sk?ref_src=twsrc%5Etfw">@prospect_sk</a></p>&mdash; Dejan Lukic (@daddydejan95) <a href="https://twitter.com/daddydejan95/status/1651249681270292480?ref_src=twsrc%5Etfw">April 26, 2023</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

                                  </div>
                               </div>
                            </div>
                         </div>
                         <div class="col-md-6 col-xl-4">
                            <div class="card rounded-4 border-0 shadow-sm h-100">
                               <div class="card-body">
                                <div class="feature">
                                   
                                    <blockquote class="twitter-tweet" data-theme="dark"><p lang="en" dir="ltr">Game changing browser extension from <a href="https://twitter.com/prospect_sk?ref_src=twsrc%5Etfw">@prospect_sk</a> check it out the AI tech behind it is great for sales professionals</p>&mdash; TJ Gaushas (@tjgaushas) <a href="https://twitter.com/tjgaushas/status/1651249468241506306?ref_src=twsrc%5Etfw">April 26, 2023</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>                        </article>

                              </div>
                               </div>
                            </div>
                         </div>
                         <div class="col-md-6 col-xl-4">
                            <div class="card rounded-4 border-0 shadow-sm h-100">
                               <div class="card-body">
                                  <div class="feature">
                                   
                                    <blockquote class="twitter-tweet" data-theme="dark"><p lang="en" dir="ltr">Boost your sales game with <a href="https://twitter.com/prospect_sk?ref_src=twsrc%5Etfw">@prospect_sk</a>! This Chrome extension simplifies prospect engagement and message customization. Don&#39;t miss out! <a href="https://twitter.com/hashtag/saleshacks?src=hash&amp;ref_src=twsrc%5Etfw">#saleshacks</a></p>&mdash; Josh Roberts (@Rebelfan1994) <a href="https://twitter.com/Rebelfan1994/status/1650530907541889025?ref_src=twsrc%5Etfw">April 24, 2023</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>                        </article>

                                  </div>
                               </div>
                            </div>
                         </div>
                         <div class="col-md-6 col-xl-4">
                            <div class="card rounded-4 border-0 shadow-sm h-100">
                               <div class="card-body">
                                  <div class="feature">
                                    <div class="feature">
                                   
                                        <blockquote class="twitter-tweet" data-theme="dark"><p lang="en" dir="ltr">Need a sales edge? Look no further than <a href="https://twitter.com/prospect_sk?ref_src=twsrc%5Etfw">@prospect_sk</a>! This amazing Chrome extension makes replying to prospects a breeze and customizes your messages. Try it now! <a href="https://twitter.com/hashtag/salestips?src=hash&amp;ref_src=twsrc%5Etfw">#salestips</a></p>&mdash; Čäršõń Çørręłł (@DoubleCC99) <a href="https://twitter.com/DoubleCC99/status/1650531168230547456?ref_src=twsrc%5Etfw">April 24, 2023</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>                        </article>

                                  </div>
                                  </div>
                               </div>
                            </div>
                         </div>
                         <div class="col-md-6 col-xl-4">
                            <div class="card rounded-4 border-0 shadow-sm h-100">
                               <div class="card-body">
                                <div class="feature">
                                   
                                    <blockquote class="twitter-tweet" data-theme="dark"><p lang="en" dir="ltr">If you&#39;re in sales, you NEED to try @prospect_pal. This Chrome extension helps you reply to prospects with ease and customize your messages. It&#39;s a game-changer! 🌟 <a href="https://twitter.com/hashtag/SalesSecretWeapon?src=hash&amp;ref_src=twsrc%5Etfw">#SalesSecretWeapon</a></p>&mdash; Meghan (@itzmeejbabyy) <a href="https://twitter.com/itzmeejbabyy/status/1646184987287330821?ref_src=twsrc%5Etfw">April 12, 2023</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>                        </article>

                              </div>
                               </div>
                            </div>
                         </div>
                         <div class="col-md-6 col-xl-4">
                            <div class="card rounded-4 border-0 shadow-sm h-100">
                               <div class="card-body">
                                <div class="feature">
                                   
                                <blockquote class="twitter-tweet" data-theme="dark"><p lang="en" dir="ltr">Just started using the <a href="https://twitter.com/prospect_sk?ref_src=twsrc%5Etfw">@prospect_sk</a> chrome extension to help me respond to my clients &amp; I can honestly say it’s helped me take my client communication to another level!</p>&mdash; Bonnie Phelps (@bcphelps) <a href="https://twitter.com/bcphelps/status/1668603526044606471?ref_src=twsrc%5Etfw">June 13, 2023</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                              </div>
                               </div>
                            </div>
                         </div>
                      </div>
                   </div>
                   <div class="section-actions text-center">
                      <!-- <ul class="btn-list btn-list-inline g-gs">
                         <li><a href="#" class="btn btn-primary btn-lg rounded-pill"><span>View all use-cases</span><em class="icon ni ni-arrow-long-right"></em></a></li>
                      </ul> -->
                   </div>
                </div>
             </section>
             <section class="section section-bottom-0 bg-light" id="pricing">
               <div class="container">
                  <div class="section-head">
                     <div class="row justify-content-center text-center">
                        <div class="col-lg-9 col-xl-8 col-xxl-6">
                           <div class="badge text-bg-primary-soft-outline text-uppercase text-tracking-1 rounded-pill px-3 py-2 mb-3">Pricing</div>
                           <h2 class="title h1">Try Our Pro Version for Free</h2>
                           <p class="lead">Experience more tailored responses with the Pro version. Set your job title and job description for more industry-specific responses that require less context. Customize and add additional tones and intentions from a database of 100+ available presets proven to convert!</p>
                        </div>
                     </div>
                  </div>
                  @include('layouts.partial.V2.pricing')

                  </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            
          </main>
    <!-- Site footer -->
    {{--<footer>
        <div class="rr tf ot ld">

            <!-- Blocks -->
            <div class="nh la io ol cc">

                <!-- 1st block -->
                <div class="ln cg cj">
                    <div class="tg">
                        <!-- Logo -->
                        <a class="nc" href="#" aria-label="PropespectPal">
                            <img src="{{asset('assets/{{asset('assets/V2/images/')}}/fav.png')}}">
                        </a>
                    </div>
                    <div class="oj ux">
                        <a class="up fo al ah ap" href="#">Terms</a> · <a
                            class="up fo al ah ap" href="#">Privacy Policy</a>
                    </div>
                </div>

                <!-- 2nd block -->
                <div class="lr lg cy">
                    <h6 class="un uy us uu tg">Prospect Sidekick</h6>
                    <ul class="oj ih">
                        <li>
                            <a class="up fo al ah ap" href="#">Prospect Sidekick Chrome</a>
                        </li>
                        <li>
                            <a class="up fo al ah ap" href="#">Prospect Sidekick Docs</a>
                        </li>
                        <li>
                            <a class="up fo al ah ap" href="#">Prospect Sidekick Email</a>
                        </li>
                        <li>
                            <a class="up fo al ah ap" href="#">Prospect Sidekick Chat</a>
                        </li>
                    </ul>
                </div>

                <!-- 3rd block -->
                <div class="lr lg cy">
                    <h6 class="un uy us uu tg">Resources</h6>
                    <ul class="oj ih">
                        <li>
                            <a class="up fo al ah ap" href="#">Tutorials</a>
                        </li>
                        <li>
                            <a class="up fo al ah ap" href="#">Shortcuts</a>
                        </li>
                        <li>
                            <a class="up fo al ah ap" href="#">Channel Partners</a>
                        </li>
                        <li>
                            <a class="up fo al ah ap" href="#">Affiliate Program</a>
                        </li>
                    </ul>
                </div>

                <!-- 4th block -->
                <div class="lr lg cy">
                    <h6 class="un uy us uu tg">Other Apps</h6>
                    <ul class="oj ih">
                        <li>
                            <a class="up fo al ah ap" href="#">Prospect Sidekick Chrome</a>
                        </li>
                        <li>
                            <a class="up fo al ah ap" href="#">Prospect Sidekick Firefox</a>
                        </li>
                        <li>
                            <a class="up fo al ah ap" href="#">Prospect Sidekick Brave</a>
                        </li>
                        <li>
                            <a class="up fo al ah ap" href="#">Prospect Sidekick Docs </a>
                        </li>
                    </ul>
                </div>

                <!-- 5th block -->
                <div class="lr lg cy">
                    <h6 class="un uy us uu tg">Prospects Pal</h6>
                    <ul class="oj ih">
                        <li>
                            <a class="up fo al ah ap" href="#">About Us</a>
                        </li>
                        <li>
                            <a class="up fo al ah ap" href="#">Our Story</a>
                        </li>
                        <li>
                            <a class="up fo al ah ap" href="#">Work With Us</a>
                        </li>
                        <li>
                            <a class="up fo al ah ap" href="#">Concat Us</a>
                        </li>
                    </ul>
                </div>

            </div>

        </div>
    </footer>--}}


@endsection

