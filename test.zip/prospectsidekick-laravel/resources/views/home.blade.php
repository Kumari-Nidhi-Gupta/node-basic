@extends('layouts.user')
@php
    $user = \Illuminate\Support\Facades\Auth::user();
@endphp
@section('content')
    {{--dashboard--}}
    
    <!-- ! Main -->
    <div class="page-header">
        <h3 class="page-title"> Account Settings </h3>
    </div>

    <div class="row">
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Profile</h4>
                    <form class="forms-sample" autocomplete="off">
                        <div class="row">
                            <div class="col-md-12 col-sm-12">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" class="form-control" name="first_name" id="first_name"
                                           value="{{ $user->first_name }}" placeholder="First Name">
                                    <span class="invalid-feedback error-msg text-red-600" id="nameError"></span>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="last_name" id="last_name"
                                           value="{{ $user->last_name }}" placeholder="Last Name">
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12">
                                <div class="form-group">
                                    <button class="btn btn-primary" type="button" id="update_name_btn">
                                        Update
                                        <span id="optimize-spinner-name" class="spinner-border spinner-border-sm"
                                              style="display: none" role="status" aria-hidden="true"></span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email</label>
                                    <input type="email" name="email" class="form-control" id="email"
                                           value="{{ $user->email }}" disabled placeholder="Email">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 col-sm-12">
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input type="password" class="form-control" name="password" id="old_password"
                                           placeholder="Password">
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12">
                                <div class="form-group">
                                    <input type="password" name="confirm_password" class="form-control" id="password"
                                           placeholder="Confirm Password">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="form-group">
                                    <label for="password"></label>
                                    <button class="btn btn-primary" type="button" id="passwordUpdate">
                                        Update
                                        <span id="optimize-spinner-password" class="spinner-border spinner-border-sm"
                                              style="display: none" role="status" aria-hidden="true"></span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h4 class="card-title">About you</h4>
                        </div>
                    </div>
                    @include('share._job', [ "user" => isset($user) ? $user : null,  ])
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Industry</label>
                                <select type="text" id="industry" name="industry" class="form-control">
                                    <option value="">Select Industry</option>
                                    @if (isset($industries))
                                        @foreach ($industries as $item)
                                            <option
                                                value={{$item->id}} {{ $item->id == old('industry', $user->industry) ? "selected" : "" }}>{{$item->name}}</option>
                                        @endforeach
                                    @endif
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 col-sm-12">
                            <div class="form-group">
                                <button type="button" id="update_about_info" class="btn btn-primary mr-2">
                                    Update
                                    <span id="optimize-spinner-job" class="spinner-border spinner-border-sm"
                                          style="display: none" role="status" aria-hidden="true"></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@push('script')
    <script>
        function checkIndustryOption() {
            const selectedOption = $("#industry option:selected").html();
            console.log(selectedOption, "selectedOption");
            if (selectedOption === 'other') {
                $("#industryDescription_wrapper").removeClass("hidden");
            } else {
                $("#industryDescription_wrapper").addClass("hidden");
                $("#industryDescription").val("");
            }
        }

        checkIndustryOption();
        $("#industry").change(function () {
            checkIndustryOption();
        });

        $("#update_about_info").click(async function () {
            const personal_website = $("#web_url").val();
            const job_title = $("#jobTitle").val();
            const job_description = $("#jobDescription").val()
            const industry = $("#industry").val();
            const industry_description = $("#industryDescription").val();
            common_helper.removeValidationErrors()
            let is_valid = true;

            if (!job_title) {
                common_helper.validationErrorSet('#jobTitle', 'Job Title is required.')
                is_valid = false;
            }

            if (!job_description) {
                common_helper.validationErrorSet('#jobDescription', 'Job Description is required.')
                is_valid = false;
            }

            if (!industry) {
                common_helper.validationErrorSet('#industry', 'Industry is required.')
                is_valid = false;
            }

            if(is_valid) {
                const params = {
                    personal_website, job_title, job_description, industry, industry_description,
                    spinner: '#optimize-spinner-job'
                }
                await updateUserData(params);
            }
        });

        $("#update_name_btn").click(async function () {
            const first_name = $("#first_name").val();
            const last_name = $("#last_name").val();
            common_helper.removeValidationErrors()
            let is_valid = true;
            if (!first_name) {
                common_helper.validationErrorSet('#first_name', 'First Name is required')
                is_valid = false;
            }
            if (!last_name) {
                common_helper.validationErrorSet('#last_name', 'Last Name is required')
                is_valid = false;
            }

            if (is_valid) {
                await updateUserData({
                    first_name, last_name,
                    spinner: '#optimize-spinner-name'
                })
            }
        });

        $("#passwordUpdate").click(async function () {
            const password = $("#password").val();
            const old_password = $("#old_password").val();
            common_helper.removeValidationErrors()
            let is_valid = true;
            if (!old_password) {
                common_helper.validationErrorSet('#old_password', 'Old Password is required')
                is_valid = false;
            }

            if (!password) {
                common_helper.validationErrorSet('#password', 'New password is required')
                is_valid = false;
            } else if (password.length < 8) {
                common_helper.validationErrorSet('#password', 'Password must be at least 8 characters.')
                is_valid = false;
            }

            if (is_valid) {
                await updateUserData({
                    password, old_password,
                    spinner: '#optimize-spinner-password'
                })
            }
        })

        async function updateUserData(params) {
            params._token = "{{ csrf_token() }}";
            $('.loading').show();
            const response = await common_helper.globalAjaxRequest({
                type: 'put',
                url: "{{ route("updateUserDataApi", ["user" => $user->id]) }}",
                data: params,
                spinner: params?.spinner
            });
            //console.log('result',response)
            if (response.msg === 'success') {
                alert("Updated.");
            } else {
                alert(response.msg);
            }

            if(response?.updated_extension_values) {
                localStorage.setItem('extension', response?.updated_extension_values)
                document.getElementById("sync-storage").click()
            }

            /*success: function(result) {
                if(result.msg === 'success') {
                    alert("Updated.");
                } else {
                    alert(result.msg);
                }
            },
            complete: function() {
                $('.loading').hide(); // Hide the loading element after the request is complete
            }*/
        }
    </script>
@endpush
