<div class="container">
                  <div class="row g-gs align-items-center justify-content-center justify-content-xl-between flex-xl-row-reverse text-center text-xl-start">
                     <div class="col-xl-6 col-xxl-5 col-lg-7 col-md-10">
                        <div class="nk-hero-gfx me-xxl-n7">
                           <div class="p-1 rounded-3 bg-gradient-primary">                             <iframe width="100%" height="450" src="https://www.youtube.com/embed/vTWhQd86Eig" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                           </div>
                        </div>
                     </div>
                     <div class="col-xxl-7 col-xl-6 col-lg-11">
                        <div class="nk-hero-content">
      


                           <h1 class="title mb-3 mb-lg-4 display-6">
                            Boost Your Sales Conversations with GPT-Powered Chrome Extension
                           </h1>
                           <p class="lead ">Prospect Sidekick: Personalized, Intelligent Sales Responses in Your Control. Skyrocket Sales Conversions Without Lengthy Prompts!</p>
                           <ul class="btn-list btn-list-inline py-3 gy-3">
                              <li><a href="/register" class="btn btn-primary btn-lg"><em class="icon ni ni-google"></em><span>Sign up with Google</span></a></li>
                              <li><a href="https://chrome.google.com/webstore/detail/prospect-sidekick/debeabfjkcoekcncbmfefgkgbdgchiej?hl=en&authuser=0" class="btn btn-light btn-lg">  <img src="https://upload.wikimedia.org/wikipedia/commons/8/87/Google_Chrome_icon_%282011%29.png" width="20px" height="20px">
<span>Add to Chrome</span></a></li>
                           </ul>
                           <p class="sub-text mt-2"><strong>*100% free </strong> to get started. No credit card required.</p>
                        </div>
                     </div>
                  </div>
               </div>
    