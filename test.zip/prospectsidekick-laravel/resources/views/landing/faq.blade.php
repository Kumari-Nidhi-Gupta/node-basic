@extends('layouts.homepage')
@section('content')
    <header class="nk-header">
        @include('landing.navbar')
    </header>

    
    <main class="nk-pages">
    <section class="section bg-light">
               <div class="container">
                  <div class="section-head">
                     <div class="row justify-content-center text-center">
                        <div class="col-xl-8">
                           <h2 class="title">Frequently Asked Questions</h2>
                           <p class="lead">If you have any questions not answered in the FAQ, please do not hesitate to contac us.</p>
                        </div>
                     </div>
                  </div>
                  <div class="section-content">
                     <div class="row g-gs justify-content-center">
                        <div class="col-xl-9 col-xxl-8">
                           <div class="accordion accordion-separated accordion-plus-minus" id="faq-1">
                              <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-1-1"> What is Prospect Sidekick? </button></h2>
                                 <div id="faq-1-1" class="accordion-collapse collapse show" data-bs-parent="#faq-1">
                                     <div class="accordion-body">
                                         Prospect Sidekick is a Chrome browser extension designed to assist you in crafting perfect responses to your clients. Simply highlight text or an email, choose your response's tone, specify your intention, and let our AI do the rest.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-2-2"> How does Prospect Sidekick work? </button></h2>
                                 <div id="faq-2-2" class="accordion-collapse collapse" data-bs-parent="#faq-2">
                                     <div class="accordion-body">
                                         Once you highlight text or an email, Prospect Sidekick uses this information to help you generate a tailored response. You can choose your desired tone, specify your intention, control the response length, and select the format of your response.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-3-3"> What are the key features of Prospect Sidekick? </button></h2>
                                 <div id="faq-3-3" class="accordion-collapse collapse" data-bs-parent="#faq-3">
                                     <div class="accordion-body">
                                         The key features of Prospect Sidekick include:
                                         <ul>
                                             <li>Highlight &amp; Respond</li>
                                             <li>Choose Your Tone</li>
                                             <li>Specify Your Intention</li>
                                             <li>Customize Length</li>
                                             <li>Text or Email Format</li>
                                             <li>Respond with a Question or Statement</li>
                                         </ul>
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-4-4"> What is the benefit of Prospect Sidekick over just using Chat GPT? </button></h2>
                                 <div id="faq-4-4" class="accordion-collapse collapse" data-bs-parent="#faq-4">
                                     <div class="accordion-body">
                                         Prospect Sidekick simplifies your communication process by eliminating the need for you to create your own prompts. The information you select directly informs the creation of a tailor-made response for your client or prospect.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-5-5"> What’s the difference between the free version, the Starter Plan, and the Pro version? </button></h2>
                                 <div id="faq-5-5" class="accordion-collapse collapse" data-bs-parent="#faq-5">
                                     <div class="accordion-body">
                                         In the Starter Plan, in addition to the standard features, you're able to use your 'job title' and 'job description' to add more context to your messages. You're also able to add up to three desired tones to your responses, instead of one in the free version. In the Pro version, you have access to all the features of the Starter Plan, with the addition of unlimited queries, and a selection from an additional 100 different tones and 50 different intentions to create a more tailored experience.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-6-6"> What is the purpose of the ‘intentions’ tab? </button></h2>
                                 <div id="faq-6-6" class="accordion-collapse collapse" data-bs-parent="#faq-6">
                                     <div class="accordion-body">
                                         The intentions tab enables you to create a specific intent with your message, guiding your conversations in the direction you want.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-7-7"> What is the purpose of the ‘tones’ tab? </button></h2>
                                 <div id="faq-7-7" class="accordion-collapse collapse" data-bs-parent="#faq-7">
                                     <div class="accordion-body">
                                         The tones tab allows you to select the desired tone of your response, aligning the 'feel' of your message with your communication style and objective.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-8-8"> What am I supposed to write in the “additional context” box at the bottom of the extension? </button></h2>
                                 <div id="faq-8-8" class="accordion-collapse collapse" data-bs-parent="#faq-8">
                                     <div class="accordion-body">
                                         The "additional context" box is for you to provide any additional direction to guide Prospect Sidekick's response.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-9-9"> What is the purpose of the ‘optimize’ button next to job description? </button></h2>
                                 <div id="faq-9-9" class="accordion-collapse collapse" data-bs-parent="#faq-9">
                                     <div class="accordion-body">
                                         The 'optimize' button enhances your job description, making it more detailed, enabling the AI to generate more intuitive and context-specific responses.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-10-10"> Will Prospect Sidekick be able to have my conversations for me? </button></h2>
                                 <div id="faq-10-10" class="accordion-collapse collapse" data-bs-parent="#faq-10">
                                     <div class="accordion-body">
                                         While Prospect Sidekick significantly simplifies your communication process, we believe that completely automating conversations isn't ideal. Our pre-engineered prompts and custom presets provide an effective way to harness AI while keeping you in control.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-11-11"> What other features are being added to Prospect Sidekick? </button></h2>
                                 <div id="faq-11-11" class="accordion-collapse collapse" data-bs-parent="#faq-11">
                                     <div class="accordion-body">
                                         We're always working on improving Prospect Sidekick and adding new features. Please stay tuned for updates on our website and through our communication channels.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-12-12"> Where can I find and install Prospect Sidekick? </button></h2>
                                 <div id="faq-12-12" class="accordion-collapse collapse" data-bs-parent="#faq-12">
                                     <div class="accordion-body">
                                         You can find and install Prospect Sidekick directly from the Chrome Web Store via this <a href="https://chrome.google.com/webstore/detail/prospect-sidekick/debeabfjkcoekcncbmfefgkgbdgchiej">link</a>.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-13-13"> How can I contact Prospect Sidekick for support or more information? </button></h2>
                                 <div id="faq-13-13" class="accordion-collapse collapse" data-bs-parent="#faq-13">
                                     <div class="accordion-body">
                                         For any support-related inquiries or for more information about Prospect Sidekick, feel free to reach out to us via email at <a href="mailto:jake@prospectsidekick.tech">jake@prospectsidekick.tech</a>.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-14-14"> How does Prospect Sidekick handle my privacy and data? </button></h2>
                                 <div id="faq-14-14" class="accordion-collapse collapse" data-bs-parent="#faq-14">
                                     <div class="accordion-body">
                                         Prospect Sidekick is committed to protecting your privacy. We collect the text you have highlighted on your screen to generate accurate and relevant responses. We may also collect usage data to improve our services and provide a better user experience. <br><br>
                             
                                         We only retain this information for as long as necessary to provide our services or as required by law. Once the information is no longer needed, we securely delete or anonymize the data. <br><br>
                             
                                         We implement appropriate technical and organizational measures to protect your personal information from unauthorized access, disclosure, alteration, or destruction. However, please be aware that no method of transmission over the internet or electronic storage is 100% secure, and we cannot guarantee the absolute security of your information. <br><br>
                             
                                         For more information, you can read our full <a href="https://prospectsidekick.tech/privacy-policy.html">Privacy Policy</a>.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#faq-15-15"> How will I receive updates and news about new features for Prospect Sidekick? </button></h2>
                                 <div id="faq-15-15" class="accordion-collapse collapse" data-bs-parent="#faq-15">
                                     <div class="accordion-body">
                                         To stay up-to-date with the latest updates and news about new features for Prospect Sidekick, you can subscribe to our newsletter on our website. Additionally, you can follow us on social media platforms like Twitter and LinkedIn.
                                     </div>
                                 </div>
                             </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
    </main>
@endsection
