@extends('layouts.homepage')
@section('content')
    <header class="nk-header">
        @include('landing.navbar')
        <style>
            .accordion-term-button {
                position: relative;
                display: flex;
                align-items: center;
                width: 100%;
                padding: var(--bs-accordion-btn-padding-y) var(--bs-accordion-btn-padding-x);
                font-size: 0.9375rem;
                color: var(--bs-accordion-btn-color);
                text-align: left;
                background-color: var(--bs-accordion-btn-bg);
                border: 0;
                border-radius: 0;
                overflow-anchor: none;
                transition: var(--bs-accordion-transition)
            }
            .accordion-term-button {
                cursor: default !important;
            }
        </style>
    </header>

    
    <main class="nk-pages">
    <section class="section bg-light">
               <div class="container">
                  <div class="section-head">
                     <div class="row justify-content-center text-center">
                        <div class="col-xl-8">
                           <h2 class="title">Terms and Conditions</h2>
                        </div>
                     </div>
                  </div>
                  <div class="section-content">
                     <div class="row g-gs justify-content-center">
                        <div class="col-xl-9 col-xxl-8">
                           <div class="accordion accordion-separated accordion-plus-minus" id="faq-1">
                              <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-term-button" data-bs-target="#faq-1-1"> Acceptance of Terms </button></h2>
                                 <div id="faq-1-1" class="accordion-collapse collapse show" data-bs-parent="#faq-1">
                                     <div class="accordion-body">
                                        By accessing or using the Prospect Sidekick website and Chrome extension (the "Services"), you agree to comply with and be bound by these Terms and Conditions (the "Terms"). If you do not agree to these Terms, please do not use the Services.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-term-button" data-bs-target="#faq-2-2"> Registration </button></h2>
                                 <div id="faq-2-2" class="accordion-collapse collapse show" data-bs-parent="#faq-2">
                                     <div class="accordion-body">
                                        To use certain features of the Services, you may be required to register for an account. You agree to provide accurate and complete information and to keep this information up to date.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-term-button" data-bs-target="#faq-3-3"> Use of Services </button></h2>
                                 <div id="faq-3-3" class="accordion-collapse collapse show" data-bs-parent="#faq-3">
                                     <div class="accordion-body">
                                        You agree to use the Services in accordance with all applicable laws and regulations. You may not use the Services in a way that is fraudulent, harmful, or infringes on the rights of others.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-term-button" data-bs-target="#faq-4-4"> Intellectual Property </button></h2>
                                 <div id="faq-4-4" class="accordion-collapse collapse show" data-bs-parent="#faq-4">
                                     <div class="accordion-body">
                                        All content, including but not limited to text, graphics, logos, and software, is the property of Prospect Sidekick or its content suppliers and is protected by international copyright laws.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-term-button" data-bs-target="#faq-5-5"> Limitation of Liability </button></h2>
                                 <div id="faq-5-5" class="accordion-collapse collapse show" data-bs-parent="#faq-5">
                                     <div class="accordion-body">
                                        Prospect Sidekick shall not be liable for any direct, indirect, incidental, or consequential damages resulting from the use or inability to use the Services.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-term-button" data-bs-target="#faq-6-6"> Privacy </button></h2>
                                 <div id="faq-6-6" class="accordion-collapse collapse show" data-bs-parent="#faq-6">
                                     <div class="accordion-body">
                                        Your use of the Services is also governed by our Privacy Policy, which can be found on our website.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-term-button" data-bs-target="#faq-7-7"> Changes to Terms </button></h2>
                                 <div id="faq-7-7" class="accordion-collapse collapse show" data-bs-parent="#faq-7">
                                     <div class="accordion-body">
                                        Prospect Sidekick reserves the right to change these Terms at any time. Continued use of the Services constitutes acceptance of the revised Terms.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-term-button" data-bs-target="#faq-8-8"> Governing Law </button></h2>
                                 <div id="faq-8-8" class="accordion-collapse collapse show" data-bs-parent="#faq-8">
                                     <div class="accordion-body">
                                        These Terms are governed by the laws of the jurisdiction in which Prospect Sidekick operates.
                                     </div>
                                 </div>
                             </div>
                             
                             <div class="accordion-item">
                                 <h2 class="accordion-header"><button class="accordion-term-button" data-bs-target="#faq-9-9"> Contact Information </button></h2>
                                 <div id="faq-9-9" class="accordion-collapse collapse show" data-bs-parent="#faq-9">
                                     <div class="accordion-body">
                                        For any questions or concerns regarding these Terms, please contact us at
                                     </div>
                                 </div>
                             </div>

                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
    </main>
@endsection
