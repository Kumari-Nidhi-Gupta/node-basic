<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <title>Prospect Sidekick</title>
    @include('layouts.partial.admin-head')
</head>


<body class="bg-gray-50 dark:bg-gray-800">
@include('layouts.partial.admin-header')
@include('layouts.partial.admin-sidebar')
@yield('content')
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
</body>

</html>
