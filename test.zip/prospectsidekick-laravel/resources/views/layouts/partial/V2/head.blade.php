<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="{{asset('build/assets/homepage-24e21271.css')}}">
<link rel="stylesheet" href="{{asset('assets/V2/css/style.css')}}">

<link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet"/>
<link rel="apple-touch-icon" sizes="180x180" href="https://prospectsidekick.tech/fav/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="https://prospectsidekick.tech/fav/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="https://prospectsidekick.tech/fav/favicon-16x16.png">
<link rel="manifest" href="https://prospectsidekick.tech/fav/site.webmanifest">

<meta property="og:title" content="Prospect Sidekick - Boost Your Sales Conversations with GPT-Powered Chrome Extension" />
<meta property="og:type" content="extension" />
<meta property="og:url" content="https://prospectsidekick.tech/" />
<meta property="og:image" content="https://prospectsidekick.tech/assets/images/fav.png" />

<script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
{{--
<script src="{{asset('assets/js/toastr.min.js')}}"></script>
--}}


