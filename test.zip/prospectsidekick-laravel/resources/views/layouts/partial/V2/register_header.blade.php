<header class="nk-header">
    @include('landing.navbar')
</header>
