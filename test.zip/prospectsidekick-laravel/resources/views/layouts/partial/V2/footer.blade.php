<footer class="nk-footer">
             <div class="section section-sm section-top-0">
           
             <div class="section section-0">
                <hr class="border-opacity-25 border-primary m-0">
                <div class="container">
                   <div class="py-4">
                      <div class="row">
                         <div class="col-md">
                            <p class="mb-2 mb-md-0">Copyright &copy; 2023 <a href="#" class="fw-bold text-base">Prospect Sidekick</a>.</p>
                         </div>
                         <div class="col-md">
                            <ul class="list list-row gx-4 justify-content-start justify-content-md-end">
                               <li><a href="{{route('terms')}}" class="link-primary">Terms</a></li>
                               <li><a href="/privacy-policy.html" class="link-primary">Privacy Policy</a></li>
                            </ul>
                         </div>
                      </div>
                   </div>
                </div>
             </div>
          </footer>
     