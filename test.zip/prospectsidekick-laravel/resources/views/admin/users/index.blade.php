@extends('layouts.admin')

@section('content')

    <div class="relative bg-gray-50 lg:ml-64 dark:bg-gray-900">
        <div class="px-4 pt-6">
            <div class="p-4 bg-white border border-gray-200 rounded-lg shadow-sm 2xl:col-span-2 dark:border-gray-700 sm:p-6 dark:bg-gray-800">
                @include("share.flash-message")
                <div class="flex justify-between items-center">
                    <a href="" class="px-3 py-1 rounded bg-sky-600 text-white">Create User</a>
                </div>


                <div class="mt-8">
                    <table class="table table-striped w-full table-auto">
                        <thead>
                            <tr class=" bg-gray-300">
                                <th class="py-2 border-b border-gray-400">First Name</th>
                                <th class="py-2 border-b border-gray-400">Last Name</th>
                                <th class="py-2 border-b border-gray-400">Email</th>
                                <th class="py-2 border-b border-gray-400">Mobile</th>
                                <th class="py-2 border-b border-gray-400">Action</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                        {{--<tr class="text-center">
                                <td class="py-2 border-b border-gray-400">John</td>
                                <td class="py-2 border-b border-gray-400">Rambo</td>
                                <td class="py-2 border-b border-gray-400">john@gmail.com</td>
                                <td class="py-2 border-b border-gray-400">9259545695</td>
                                <td class="py-2 border-b border-gray-400">
                                    <a href="">EDIT</a>
                                </td>
                            </tr>
                            <tr class="text-center">
                                <td class="py-2 border-b border-gray-400">John</td>
                                <td class="py-2 border-b border-gray-400">Rambo</td>
                                <td class="py-2 border-b border-gray-400">john@gmail.com</td>
                                <td class="py-2 border-b border-gray-400">9259545695</td>
                                <td class="py-2 border-b border-gray-400">
                                    <a href="">EDIT</a>
                                </td>
                            </tr> --}}
                            @foreach($users as $user)
                            <tr class="text-center">
                                <td class="py-2 border-b border-gray-400">{{ $user->first_name ? $user->first_name : "---" }}</td>
                                <td class="py-2 border-b border-gray-400">{{ $user->last_name ? $user->last_name : "---" }}</td>
                                <td class="py-2 border-b border-gray-400">{{ $user->email ? $user->email : "---" }}</td>
                                <td class="py-2 border-b border-gray-400">{{ $user->phone ? $user->phone : "---" }}</td>
                                <td class="py-2 border-b border-gray-400">
                                    <a href="javascript:void(0);" class="px-3 py-1 rounded bg-sky-600 text-white" onclick="editUser({{ $user->id }})">EDIT</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                        
                    </table>
                </div>
            </div>
        </div>
    </div>


<script>
    function editUser(id){
        console.log('userId :>> ', id);
    }
</script>
@endsection
