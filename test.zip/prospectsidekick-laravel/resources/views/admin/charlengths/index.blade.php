@extends('layouts.admin')

@section('content')
{{--dashboard--}}

<div class="relative bg-gray-50 lg:ml-64 dark:bg-gray-900">
    <div class="px-4 pt-6">
        <div
            class="p-4 bg-white border border-gray-200 rounded-lg shadow-sm 2xl:col-span-2 dark:border-gray-700 sm:p-6 dark:bg-gray-800">
            <div class="flex justify-between items-center">
                <a class="px-3 py-1 rounded bg-sky-600 text-white" href="javascript:void(0);"
                    data-modal-target="addcharlength" data-modal-toggle="addcharlength">Create</a>
            </div>
            <div class="mt-8">
                <table class="table table-striped w-full table-auto">
                    <thead>
                        <tr class=" bg-gray-300">
                            <th class="py-2 border-b border-gray-400">Name</th>
                            <th class="py-2 border-b border-gray-400">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($character_lengths as $charlength)
                        <tr class="text-center">
                            <td class="py-2 border-b border-gray-400">{{ $charlength->name }}</td>
                            </td>
                            <td class="py-2 border-b border-gray-400">
                                <a class="px-3 py-1 rounded bg-sky-600 text-white" href="javascript:void(0);" onclick="editCharLength({{ $charlength->id }})" id="updateCharLengthBtn" data-modal-toggle="updateCharLengthModal">Edit</a>
                                <a class="px-3 py-1 rounded bg-sky-600 text-white" href="javascript:void(0);" onclick="deleteCharLength({{ $charlength->id }})">Delete</a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- Add CharLength modal Start -->
<div id="addcharlength" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-modal md:h-full">
    <div class="relative p-4 w-full max-w-xl h-full md:h-auto">
        <div class="relative p-4 bg-white rounded-lg shadow dark:bg-gray-800 sm:p-5">
            <div class="flex justify-between items-center pb-4 mb-4 rounded-t border-b sm:mb-5 dark:border-gray-600">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    Create
                </h3>
                <button type="button"
                    class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white"
                    data-modal-toggle="addcharlength">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd"
                            d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                            clip-rule="evenodd"></path>
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <form action="#" id="addCharLength">
                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Character Name</label>
                        <input type="text" name="name" id="name" value="" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" >
                        <p id="nameError" class="text-red-600"></p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <button onclick="createCharLength(event)" type="button" class="px-3 py-1 rounded bg-sky-600 text-white">
                        Create
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Add CharLength modal End -->


<!-- Update CharLength modal Start -->
<div id="updateCharLengthModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-modal md:h-full">
    <div class="relative p-4 w-full max-w-xl h-full md:h-auto">
        <div class="relative p-4 bg-white rounded-lg shadow dark:bg-gray-800 sm:p-5">
            <div class="flex justify-between items-center pb-4 mb-4 rounded-t border-b sm:mb-5 dark:border-gray-600">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    Update
                </h3>
                <button type="button"
                    class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white"
                    data-modal-toggle="updateCharLengthModal">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd"
                            d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                            clip-rule="evenodd"></path>
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <form action="#" id="updateCharLengthForm">
                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Character Name</label>
                        <input type="text" name="name" id="updateCharName" value="" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" >
                        <p id="updateCharNameError" class="text-red-600"></p>
                        <input type="hidden" name="id" id="charId" value="">
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <button onclick="updateCharLength()" type="button" class="px-3 py-1 rounded bg-sky-600 text-white">
                        Update
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Update CharLength modal End -->


<script>
function createCharLength(e) {
    e.preventDefault();
    var formData = $('#addCharLength').serialize();
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        type: "POST",
        url: "{{ route('admin.charlengths') }}",
        data: formData,
        success: function(response) {
            $("#addcharlength :input").val("");
            if (response.status) {
                showToastMessage(response.message);
                loadWindow();
            } else {
                $("#nameError").html(response.errors.name[0]);
            }
        }
    });
}

function editCharLength(id) {
    $.ajax({
        type: "GET",
        url: "{{ route('admin.charlengths') }}" + '/' + id,
        success: function(response) {
            if(response.status){
                $("#updateCharName").val(response.data.name);
                $("#charId").val(response.data.id);
            }
        }
    });
}

function updateCharLength(){

    var id = $("#charId").val();
    var name = $("#updateCharName").val();
    var data = {
        id: id,
        name: name
    };

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    
    $.ajax({
        type: "PUT",
        url: "{{ route('admin.charlengths') }}" + '/' + id,
        data: data,
        success: function (response) {
            if(response.status){
                showToastMessage(response.message);
                loadWindow();
            }else {
                $("#updateCharNameError").html(response.errors.name[0]);
            }
        }
    });
}

function deleteCharLength(id) {
    if (!confirm('Are you sure you want to delete this character length')) {
        return false;
    }
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        type: "Delete",
        url: "{{ route('admin.charlengths') }}" + '/' + id,
        success: function(response) {
            if (response.status) {
                showToastMessage(response.message)
                loadWindow();
            }
        }
    });
}

function loadWindow() {
    var currentUrl = window.location.href;
    window.location.href = currentUrl;
}

function showToastMessage(message) {
    Toastify({
        text: `${message}`,
        duration: 3000,
        newWindow: true,
        close: true,
        gravity: "top",
        position: "right",
        stopOnFocus: true,
        style: {
            background: "linear-gradient(to right, #00b09b, #96c93d)",
        },
        callback: function(){
            console.log('Clear Toast :>> ');
        },
        onClick: function(){
            console.log("Toast Clicked");
        }
    }).showToast();
}

document.addEventListener("DOMContentLoaded", function(event) {
    document.getElementById('updateCharLengthBtn').click();
});
</script>

@endsection