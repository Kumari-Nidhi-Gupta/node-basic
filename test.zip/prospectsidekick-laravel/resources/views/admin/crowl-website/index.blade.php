@extends('layouts.admin')

@section('content')
    {{--dashboard--}}

    <div class="relative bg-gray-50 lg:ml-64 dark:bg-gray-900">
        <div class="px-4 pt-6">
            <div class="p-4 bg-white border border-gray-200 rounded-lg shadow-sm 2xl:col-span-2 dark:border-gray-700 sm:p-6 dark:bg-gray-800"> 
                <div class="mt-8">
                    
                    <div class="grid mb-4">
                        <label for="name" class="mb-2 text-sm font-medium">Website URL:</label>
                        <input type="text" name="name" id="web_url" class="w-medium">
                    </div>

                    <div class="flex items-center space-x-4">
                        <button onclick="scrapWeb(event)" type="button" class="submit-btn px-3 py-1 bg-sky-600 text-white">
                            Submit
                        </button>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>


    <div class="relative bg-gray-50 lg:ml-64 dark:bg-gray-900">
        <div class="px-4 pt-6">
            <div class="p-4 bg-white border border-gray-200 rounded-lg shadow-sm 2xl:col-span-2 dark:border-gray-700 sm:p-6 dark:bg-gray-800">
                <div class="mt-8">
                    <h1 class="mb-2 text-lg font-medium">Response</h1>
                    <div class="scrap-res"></div>
                </div>
            </div>
        </div>
    </div>
    
<script>
function scrapWeb(e) {
    e.preventDefault();
    var web_url = $('#web_url').val();

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('.submit-btn').html('Please wait...');
    $.ajax({
        type: "POST",
        url: "{{ route('admin.scrape') }}",
        data: {web_url:web_url},
        success: function(response) {
            $('.submit-btn').html('Submit');
            var result = response.data;
            console.log(result);
            $('.scrap-res').html(`
                <table class="table">
                    <tr>
                        <td class="py-2"><b>Title: </b></td>
                        <td class="py-2">`+result.title+`</td>
                    </tr>
                    <tr>
                        <td class="py-2"><b>Description: </b></td>
                        <td class="py-2">`+result.description+`</td>
                    </tr>
                </table>
            `);
        }
    });
}    
</script>
@endsection

