@extends('layouts.admin')

@section('content')
    {{--dashboard--}}

    <div class="relative bg-gray-50 lg:ml-64 dark:bg-gray-900">
        <div class="px-4 pt-6">
            <div class="p-4 bg-white border border-gray-200 rounded-lg shadow-sm 2xl:col-span-2 dark:border-gray-700 sm:p-6 dark:bg-gray-800">
                @include("share.flash-message")
                <div class="flex justify-between items-center">
                    <a href="javascrip:void(0)" class="px-3 py-1 rounded bg-sky-600 text-white" href="javascript:void(0);"
                    data-modal-target="addPlan" data-modal-toggle="addPlan">Create Plan</a>
                </div>

                <div class="mt-8">
                    <table class="table table-striped w-full table-auto">
                        <thead>
                        <tr class=" bg-gray-300">
                            <th class="py-2 border-b border-gray-400">Plan Name</th>
                            <th class="py-2 border-b border-gray-400">Plan Intverval</th>
                            <th class="py-2 border-b border-gray-400">Plan Amount</th>
                            <th class="py-2 border-b border-gray-400">Plan Trial Period</th>
                            <th class="py-2 border-b border-gray-400">#</th>
                        </tr>
                        </thead>
                        @if ($plans->count() > 0)
                            <tbody>
                            @foreach($plans as $plan)
                                <tr class="text-center">
                                    <td class="py-2 border-b border-gray-400">{{ $plan->name }}</td>
                                    <td class="py-2 border-b border-gray-400">{{ $plan->plan_interval }}</td>
                                    <td class="py-2 border-b border-gray-400">{{ $plan->amount }}</td>
                                    <td class="py-2 border-b border-gray-400">{{ $plan->trial_period_days }}</td>
                                    <td class="py-2 border-b border-gray-400"> 
                                       <a class="px-3 py-1 rounded bg-sky-600 text-white" href="javascript:void(0);" onclick="editPlan({{ $plan->id }})" id="updatePlanBtn" data-modal-toggle="updatePlanModal">Edit</a>
                                       <a class="px-3 py-1 rounded bg-sky-600 text-white" href="javascript:void(0);" onclick="deletePlan({{ $plan->id }})">Delete</a>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        @endif
                    </table>
                </div>
            </div>
        </div>
    </div>

<!-- ======= Add Plan modal Start ======== -->
<div id="addPlan" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-modal md:h-full">
    <div class="relative p-4 w-full max-w-xl h-full md:h-auto">
        <div class="relative p-4 bg-white rounded-lg shadow dark:bg-gray-800 sm:p-5">
            <div class="flex justify-between items-center pb-4 mb-4 rounded-t border-b sm:mb-5 dark:border-gray-600">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    Add Plan
                </h3>
                <button type="button"
                    class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white"
                    data-modal-toggle="addPlan">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd">
                        </path>
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <form action="#" id="addPlanForm">
                <p class="text-red-600 formError"></p>
                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label>Plan Name</label>
                        <input type="text" name="name" id="plan_name"  class="text-md rounded-lg block w-full">
                    </div>
                </div>

                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label>Plan Option</label>
                        <textarea name="plan_option" id="plan_option" class="text-md rounded-lg block w-full"></textarea>
                    </div>
                </div>

                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label>Description</label>
                        <textarea name="plan_description" id="plan_description" class="text-md rounded-lg block w-full"></textarea>
                    </div>
                </div>

                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label>Amount</label>
                        <input type="number" name="amount" id="plan_amount"  class="text-md rounded-lg block w-full">
                    </div>
                </div>

                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label>Plan Interval</label>
                        <select name="plan_interval" class="text-md rounded-lg block w-full">
                            <option value="year">Yearly</option>
                            <option value="month">Monthly</option>
                        </select>
                    </div>
                </div>

                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label>Trial days</label>
                        <input type="number" name="trial_period_days" id="trial_period_days" value="0"  class="text-md rounded-lg block w-full">
                    </div>
                </div>

                <div class="flex items-center space-x-4">
                    <button onclick="createPlan(event)" type="button" class="px-3 py-1 rounded bg-sky-600 text-white">
                        Create
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- ======= Update Plan modal End ========= -->
<div id="updatePlanModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-modal md:h-full">
    <div class="relative p-4 w-full max-w-xl h-full md:h-auto">
        <div class="relative p-4 bg-white rounded-lg shadow dark:bg-gray-800 sm:p-5">
            <div class="flex justify-between items-center pb-4 mb-4 rounded-t border-b sm:mb-5 dark:border-gray-600">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    Update Plan
                </h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-toggle="updatePlanModal">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd">
                        </path>
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <form action="#" id="updatePlanForm">
                <p class="text-red-600 formError"></p>
                <input type="text" name="id" id="u_plan_id"  class="text-md rounded-lg block w-full">
                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label>Plan Name</label>
                        <input type="text" name="name" id="u_plan_name"  class="text-md rounded-lg block w-full">
                    </div>
                </div>

                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label>Plan Option</label>
                        <textarea name="plan_option" id="u_plan_option" class="text-md rounded-lg block w-full"></textarea>
                    </div>
                </div>

                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label>Description</label>
                        <textarea name="plan_description" id="u_plan_description" class="text-md rounded-lg block w-full"></textarea>
                    </div>
                </div>

                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label>Amount</label>
                        <input type="number" name="amount" id="u_plan_amount"  class="text-md rounded-lg block w-full">
                    </div>
                </div>

                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label>Plan Interval</label>
                        <select name="plan_interval" id="u_plan_interval" class="text-md rounded-lg block w-full">
                            <option value="year">Yearly</option>
                            <option value="month">Monthly</option>
                        </select>
                    </div>
                </div>

                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label>Trial days</label>
                        <input type="number" name="trial_period_days" id="u_trial_period_days" value="0"  class="text-md rounded-lg block w-full">
                    </div>
                </div>

                <div class="flex items-center space-x-4">
                    <button onclick="updatePlan(event)" type="button" class="px-3 py-1 rounded bg-sky-600 text-white">
                        Update
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- ======================================= -->

<script>
function createPlan(e) {
    e.preventDefault();
    var formData = $('#addPlanForm').serialize();
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        type: "POST",
        url: "{{ route('admin.plans.store') }}",
        data: formData,
        success: function(response) {
            
            if (response.status) {
                showToastMessage(response.message);
                loadWindow();
            } else {
                $(".formError").html(response.errors.name[0]);
                $(".formError").html(response.errors.amount[0]);
            }
        }
    });
}

function editPlan(id) {
    $.ajax({
        type: "GET",
        url: "{{route('admin.plans.getplan')}}?id="+id,
        success: function(response) {
            $("#u_plan_name").val(response.data.name);
            $("#u_plan_option").html(response.data.plan_option);
            $("#u_plan_description").html(response.data.plan_description);
            $("#u_plan_amount").val(response.data.amount);
            $("#u_plan_interval").val(response.data.plan_interval);
            $("#u_trial_period_days").val(response.data.trial_period_days);
            $("#u_plan_id").val(response.data.id);
            
        }
    });
}

function updatePlan(e) {
    e.preventDefault();
    var formData = $('#updatePlanForm').serialize();
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        type: "POST",
        url: "{{ route('admin.plans.updateplan') }}",
        data: formData,
        success: function(response) {
            
            if (response.status) {
                showToastMessage(response.message);
                loadWindow();
            } else {
                $(".formError").html(response.errors.name[0]);
                $(".formError").html(response.errors.amount[0]);
            }
        }
    });
}

function deletePlan(id) {
    if (!confirm('Are you sure you want to delete this Plan?')) {
        return false;
    }

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $.ajax({
        type: "Delete",
        url: "{{ route('admin.plans.deleteplan') }}?id="+id,
        success: function(response) {
            if (response.status) {
                showToastMessage(response.message);
                loadWindow();
            }
        }
    });
}

function showToastMessage(message) {
    Toastify({
        text: `${message}`,
        duration: 3000,
        newWindow: true,
        close: true,
        gravity: "top",
        position: "right",
        stopOnFocus: true,
        style: {
            background: "linear-gradient(to right, #00b09b, #96c93d)",
        },
    }).showToast();
}

function loadWindow() {
    var currentUrl = window.location.href;
    window.location.href = currentUrl;
}
</script>
@endsection
