<?php

namespace App\Utils;

class AppConstant
{

    const SUBSCRIPTION_DAYS = 30;

}
