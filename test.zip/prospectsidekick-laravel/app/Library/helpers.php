<?php

//todo add an annual plan calculation
use App\Models\Plan;

if (!function_exists('getPlansAnnually')) {
    function getPlansAnnually()
    {

    }
}

//todo  get a discount for a plan if any
if (!function_exists('getDiscounts()')) {
    function getDiscounts(Plan $plan)
    {

    }
}


?>
