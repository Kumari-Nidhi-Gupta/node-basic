<?php

namespace App\Contracts;

interface UserInterface{}
