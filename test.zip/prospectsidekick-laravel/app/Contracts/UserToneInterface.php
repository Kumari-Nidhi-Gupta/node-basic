<?php

namespace App\Contracts;

interface UserToneInterface
{}
