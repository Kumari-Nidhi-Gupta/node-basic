<?php

namespace App\Contracts;

use App\Models\Guest;

interface GuestHelperInterface
{
}
