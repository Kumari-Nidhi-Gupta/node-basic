<?php

namespace App\Contracts;

interface LoginBaseInterface
{

}
