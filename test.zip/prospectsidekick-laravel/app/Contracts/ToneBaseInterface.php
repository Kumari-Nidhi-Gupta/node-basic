<?php

namespace App\Contracts;

interface ToneBaseInterface
{
}
