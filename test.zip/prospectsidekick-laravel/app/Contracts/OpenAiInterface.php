<?php

namespace App\Contracts;

interface OpenAiInterface{}
