<?php

namespace App\Contracts;

interface UserCharacterLengthInterface
{

}
