<?php

namespace App\Contracts;

interface IntentionBaseInterface
{

}
