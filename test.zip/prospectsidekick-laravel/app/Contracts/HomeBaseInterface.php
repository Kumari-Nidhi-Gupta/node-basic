<?php

namespace App\Contracts;

interface HomeBaseInterface
{

}
