<?php

namespace App\Contracts;

interface CharacterLengthBaseInterface
{

}
