<?php

namespace App\Contracts;

interface AboutInterface{}
