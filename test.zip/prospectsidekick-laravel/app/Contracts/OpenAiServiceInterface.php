<?php

namespace App\Contracts;

interface OpenAiServiceInterface{}
