<?php

namespace App\Contracts;

interface HomeServiceInterface
{

}
