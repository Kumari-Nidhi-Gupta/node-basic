<?php

namespace App\Contracts;

interface AboutBaseInterface{}
