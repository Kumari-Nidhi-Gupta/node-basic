<?php

namespace App\Contracts;

interface RegisterBaseInterface
{

}
