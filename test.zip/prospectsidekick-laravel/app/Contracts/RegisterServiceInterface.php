<?php

namespace App\Contracts;

interface RegisterServiceInterface
{

}
