<?php

namespace App\Contracts;

interface LoginServiceInterface
{

}
