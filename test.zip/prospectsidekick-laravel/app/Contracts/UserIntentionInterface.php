<?php

namespace App\Contracts;

interface UserIntentionInterface
{

}
