<?php

namespace App\Service;

use App\Contracts\OpenAiServiceInterface;
use GuzzleHttp\Client;
use Mockery\Exception;
use OpenAI\Responses\Chat\CreateResponse;
use OpenAI;
use Tectalic\OpenAi\Authentication;
use Tectalic\OpenAi\ClientException;
use Tectalic\OpenAi\Manager;
use Tectalic\OpenAi\Models\AbstractModel;
use Tectalic\OpenAi\Models\AbstractModelCollection;
use Tectalic\OpenAi\Models\ChatCompletions\CreateRequest;
use thiagoalessio\TesseractOCR\TesseractOCR;
use Illuminate\Support\Facades\Storage;

use Google\Cloud\Vision\V1\ImageAnnotatorClient;
use Google\Cloud\Vision\V1\Image;
use Google\Cloud\Core\ExponentialBackoff;
use Google\Cloud\Core\ServiceBuilder;


class OpenAiService implements OpenAiServiceInterface
{
    const  MAX_TOKENS = 40960;

    private OpenAI\Client $client;
    private \Tectalic\OpenAi\Client $openAiClient;

    public function __construct()
    {
        $OPEN_AI_KEY = config("app.OPEN_AI_KEY");
        $this->client = OpenAI::client($OPEN_AI_KEY);
        $this->openAiClient = Manager::build(new Client(), new Authentication($OPEN_AI_KEY));
    }

    /**
     * @param $content
     * @return mixed|object|CreateResponse|AbstractModel|AbstractModelCollection
     * @throws ClientException
     */
    public function searchOpenAi($content): mixed
    {
        try {
            return $this->client->chat()->create([
                'model' => 'gpt-4',
                //'model' => 'gpt-3.5-turbo',
                'temperature' => 0,
                'frequency_penalty' => 0,
                'presence_penalty' => 0,
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => $content
                    ],
                ],
            ]);
        }catch (Exception $e){
            return $e->getMessage();
        }
    }

    public function searchOpenAiThreeTurbo($content): mixed
    {
        try {
            return $this->client->chat()->create([
                'model' => 'gpt-3.5-turbo',
                'temperature' => 0,
                'frequency_penalty' => 0,
                'presence_penalty' => 0,
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => $content
                    ],
                ],
            ]);
        }catch (Exception $e){
            return $e->getMessage();
        }
    }

    /**
     * @param $content
     * @return mixed|object|CreateResponse|AbstractModel|AbstractModelCollection
     * @throws ClientException
     */
    public function searchOpenAi2($content): mixed
    {
        try {
        return $this->openAiClient->chatCompletions()->create(
            new CreateRequest([
                'model' => 'gpt-3.5-turbo',
                'temperature' => 0,
                'frequency_penalty' => 0,
                'presence_penalty' => 0,
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => $content
                    ],
                ],
            ]))->toModel();
        }catch (Exception $e){
            return $e->getMessage();
        }
    }

    /**
     * @param $content
     * @return mixed|object|CreateResponse|AbstractModel|AbstractModelCollection
     * @throws ClientException
     */
    public function genrateImageOpenAi2($content): mixed
    {
        try {
            return $this->client->images()->create([
                'prompt' => $content,
                'n' => 2,
                'size' => '1024x1024',

            ]);
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $content
     * @return mixed|object|CreateResponse|AbstractModel|AbstractModelCollection
     * @throws ClientException
     */

    public function searchImageOpenAi2($content): mixed
    {
        try {
            $uploadedImage = $content;
            $imageName = time() . '.' . $uploadedImage->extension();
            $uploadedImage->move(public_path('images'), $imageName);
            $imagePath = public_path('images/' . $imageName);
            $tesseract =( new TesseractOCR($imagePath))->lang('eng');
            $extractedText = $tesseract->run();
            
            $correctGrammer = 'Please convert two person chat data in JSON format (It should always contain infomation like message,Sender and time. If time is not there always return time 00:00) Also if message content is duplicate(Exact match) please remove duplicate. Here is the chat string with both person messages also if possible please arrange the chat in correct order: /n'. $extractedText;
            $result =  $this->searchOpenAiThreeTurbo($correctGrammer);
            unlink($imagePath);

            $res_content = json_decode($result['choices'][0]['message']['content']);

            return ['status' => 'success', 'res' => $res_content, 'ocr' => $extractedText, 'raw_data_gpt' => $result['choices'][0]['message']['content'] ];
        } catch (Exception $e) {
            return ['status' => 'fail','res' => 'Text could not be extracted from image'];
        }
    }

    /**
     * @param $content
     * @return mixed|object|CreateResponse|AbstractModel|AbstractModelCollection
     * @throws ClientException
     */
    public function searchCaptureImageOpenAi($base64Image): mixed
    {
        try {

            $base64Image = str_replace('data:image/png;base64,', '', $base64Image);
            // Decode the Base64 image and save it as a temporary file
            $tempImagePath = tempnam(sys_get_temp_dir(), 'ocr');
            file_put_contents($tempImagePath, base64_decode($base64Image));

            $extractedText = (new TesseractOCR($tempImagePath))
            ->lang('eng') // Set the language for OCR (e.g., English)
            ->run();

            // Delete the temporary image file
            unlink($tempImagePath);

            $jfromat = `[
                    {message: "message here", sender: "sender name Person 1 or Person 2", time: "00:00"},
                    {message: "message here", sender: "sender name Person 1 or Person 2", time: "00:00"},
                ]`;
            $correctGrammer = 'Please convert two person chat data in JSON format (It should always contain infomation like message,Sender and time. If time is not there always return time 00:00) Also if message content is duplicate(Exact match) please remove duplicate.I need this kind of JSON format: '.$jfromat.'. Here is the chat string with both person messages also if possible please arrange the chat in correct order: /n'. $extractedText;
            $result =  $this->searchOpenAiThreeTurbo($correctGrammer);
            $res_content = json_decode($result['choices'][0]['message']['content']);

           return ['status' => 'success', 'res' => $res_content, 'ocr' => $extractedText, 'raw_data_gpt' => $result['choices'][0]['message']['content'] ];
        } catch (Exception $e) {
            return ['status' => 'fail','res' => 'Text could not be extracted from image'];
        }
    }

    public function performGoogleVisionOCR($imageContent): mixed
    {
        $client = new ImageAnnotatorClient();
        // Construct an Image object.
        $image = (new Image())
            ->setContent($imageContent);

        // Perform OCR on the image.
        $response = $client->textDetection($image);
        $annotations = $response->getTextAnnotations();

        $client->close();

        $extractedText = '';
        foreach ($annotations as $annotation) {
            $extractedText .= $annotation->getDescription() . ' ';
        }
        
        $jfromat = `[
                    {message: "message here", sender: "sender name Person 1 or Person 2", time: "00:00"},
                    {message: "message here", sender: "sender name Person 1 or Person 2", time: "00:00"},
                ]`;
        $correctGrammer = 'Please convert two person chat data in JSON format (It should always contain infomation like message,Sender and time. If time is not there always return time 00:00) Also if message content is duplicate(Exact match) please remove duplicate.I need this kind of JSON format: '.$jfromat.'. Here is the chat string with both person messages also if possible please arrange the chat in correct order: /n'. $extractedText;
        $result =  $this->searchOpenAiThreeTurbo($correctGrammer);
        $res_content = json_decode($result['choices'][0]['message']['content']);
        return ['status' => 'success', 'res' => $res_content, 'ocr' => $extractedText, 'raw_data_gpt' => $result['choices'][0]['message']['content'] ];

    }

    public function performGoogleVisionOCROnCaptureImage($base64Image): mixed
    {
        try {
            $base64Image = str_replace('data:image/png;base64,', '', $base64Image);
            // Decode the Base64 image and save it as a temporary file
            $tempImagePath = tempnam(sys_get_temp_dir(), 'ocr');
            file_put_contents($tempImagePath, base64_decode($base64Image));

            // Initialize the ImageAnnotatorClient
            $imageAnnotator = new ImageAnnotatorClient();

            // Perform OCR on the image
            $image = file_get_contents($tempImagePath);
            $response = $imageAnnotator->textDetection($image);
            $annotations = $response->getTextAnnotations();

            // Extract and return the extracted text
            $extractedText = '';
            foreach ($annotations as $annotation) {
                $extractedText .= $annotation->getDescription() . ' ';
            }

            // Close the ImageAnnotatorClient
            $imageAnnotator->close();
            // Delete the temporary image file
            unlink($tempImagePath);
            
            $jfromat = `[
                    {message: "message here", sender: "sender name Person 1 or Person 2", time: "00:00"},
                    {message: "message here", sender: "sender name Person 1 or Person 2", time: "00:00"},
                ]`;
            $correctGrammer = 'Please convert two person chat data in JSON format (It should always contain infomation like message,Sender and time. If time is not there always return time 00:00) Also if message content is duplicate(Exact match) please remove duplicate.I need this kind of JSON format: '.$jfromat.'. Here is the chat string with both person messages also if possible please arrange the chat in correct order: /n'. $extractedText;
            $result =  $this->searchOpenAiThreeTurbo($correctGrammer);
            $res_content = json_decode($result['choices'][0]['message']['content']);

            return ['status' => 'success', 'res' => $res_content, 'raw_data_gpt' => $result['choices'][0]['message']['content'], 'ocr' => $extractedText ];
            
        } catch (Exception $e) {
            return ['status' => 'fail','res' => 'Text could not be extracted from image'];
        }
    }


    /**
     * @param array $services
     * @param array $keywords
     * @return array
     * @throws ClientException
     */
    public function groupKeywordIntoServices(array $services, array $keywords): array
    {
        //$services = ['Fashion', 'Electronics', 'Vehicles'];
        ///$keywords = ['baby wears', 'Adidas foot wear', 'Toyota', 'Mercedes Benz', 'Apple watch', 'samsung LED', 'Macbook pro'];
        $responses = [];
        $servicesContent = "use the following array " . json_encode($services) . " as array key to group this data ". json_encode($keywords) . " return them as json";
        $servicesTokens = str_word_count($servicesContent);
        $maxKeywordTokens = self::MAX_TOKENS - $servicesTokens;
        $keywordChunks = [];
        $chunk = [];
        $chunkTokens = 0;
        foreach ($keywords as $keyword) {
            $keywordTokens = str_word_count($keyword);
            if (($chunkTokens + $keywordTokens) > $maxKeywordTokens) {
                $keywordChunks[] = $chunk;
                $chunk = [$keyword];
                $chunkTokens = $keywordTokens;
            } else {
                $chunk[] = $keyword;
                $chunkTokens += $keywordTokens;
            }
        }

        if (!empty($chunk)) {
            $keywordChunks[] = $chunk;
        }

        foreach ($keywordChunks as $chunk) {
            $content = "use the following array " . json_encode($services) . " as array key to group this data " . json_encode($chunk) . " return them as json";
            try {
                $result = $this->searchOpenAi($content)->toArray();
            }catch (\Exception $e){
                $result = $this->searchOpenAi2($content)->toArray();
            }
            $newKeywords = json_decode($result['choices'][0]['message']['content'], true);

            if (!empty($newKeywords)) {
                $responses[] = array_merge_recursive($responses, $newKeywords);
            }
        }
        return $responses;
    }

}
