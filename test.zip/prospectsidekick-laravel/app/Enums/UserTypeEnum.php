<?php

namespace App\Enums;

class UserTypeEnum
{
    const TYPE = ['ext', 'app'];

}
