<?php

namespace App\Http\Controllers\API\V1;


use App\Contracts\OpenAiInterface;
use App\Http\Controllers\Controller;
use App\Http\Requests\ImageUploadRequest;
use App\Http\Requests\OpenAi\SearchRequest;
use App\Service\OpenAiService;
use Tectalic\OpenAi\ClientException;
use Illuminate\Http\Request;
//use Google\Cloud\Vision\V1\ImageAnnotatorClient;
//use Google\Cloud\Vision\V1\Image;
//use Google\Cloud\Core\ExponentialBackoff;
use App\Models\WebNotification;

class OpenAiController extends Controller
{

    /*public function __construct(private readonly OpenAiInterface $openAi){
    }*/

    /**
     * @param SearchRequest $request
     * @return array
     * @throws ClientException
     */
    public function searchOpenAi(SearchRequest $request): array
    {
        $content =  $request->search;
        $request_model = ($request->request_model) ? $request->request_model : 'v3';

        if($request_model=='v4'){
            return (new OpenAiService())->searchOpenAi($content)->toArray();
        }else{
            return (new OpenAiService())->searchOpenAiThreeTurbo($content)->toArray();
        }
        
        
    }

    /**
     * @param SearchRequest $request
     * @return array
     * @throws ClientException
     */

     public function imageGenOpenAi(Request $request): array
     {
         $content =  $request->search;
         return (new OpenAiService())->genrateImageOpenAi2($content)->toArray();
     }

     /**
      * @param ImageUploadRequest $request
      * @return array
      * @throws ClientException
      */
 
     public function searchImageOpenAi(ImageUploadRequest $request):array 
     {
         $image =  $request->image;
         $result = (new OpenAiService())->searchImageOpenAi2($image);
         return $result;
     }

     public function searchCaptureImageOpenAi(Request $request) 
     {
         $image =  $request->image;
         $result = (new OpenAiService())->searchCaptureImageOpenAi($image);
         return $result;
     }

    public function performGoogleVisionOCR(Request $request)
    {
        $imageContent = file_get_contents($request->file('image')->getPathname());

        $result = (new OpenAiService())->performGoogleVisionOCR($imageContent);
        return $result;
    }

    public function performGoogleVisionOCROnCaptureImage(Request $request)
    {
        //$imageContent =  $request->image;
        $base64Image = $request->input('image');

        $result = (new OpenAiService())->performGoogleVisionOCROnCaptureImage($base64Image);
        return $result;
    }

    public function getNotification(Request $request){
       $browserId =  $request->browserId;
       $notifications = WebNotification::where(function($query) use ($browserId) {
           $query->where('seen', 'NOT LIKE', '%'.$browserId.'%')->orWhereNull('seen');
       })->get();
       
       foreach($notifications as $noti){
           $noti->seen = ($noti->seen) ? $noti->seen.','.$browserId : $browserId;
           $noti->save();
       }

       return $notifications;
       
    }


}
