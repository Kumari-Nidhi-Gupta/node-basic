<?php

namespace App\Http\Controllers;

use App\Http\Requests\PlansRequest;
use App\Models\Plan;
use App\Service\PlanService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Industry;
use App\Models\CharacterLength;
use App\Models\Intention;
use App\Models\Tone;
use App\Models\User;
use App\Models\Subscription;
use App\Models\WebNotification;

use Illuminate\Support\Facades\Validator;
//use GuzzleHttp\Client;
use Goutte\Client;

class AdminController extends Controller
{
    public $per_page = 10;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request) {
        $user = Auth::user();
        if($user->id != 1) {
            return redirect()->route("home");
        }

        // get total users
        $users = User::whereDoesntHave('roles', function($query) {
            $query->whereIn('name', ['super_admin', 'admin']);
        })->get();

        $pro_subscription_user = [];
        foreach($users as $user){
            $is_pro_subscription = Subscription::where('user_id', $user->id)->where('name', 'Pro')->count();
            if($is_pro_subscription > 0){
                $pro_subscription_user[] = $user;
            }
        }

        
        $total_pro_subscription_user = count($pro_subscription_user);
        $total_free_subscription_user = $users->count() - $total_pro_subscription_user;

        $total_pro_perc = ($total_pro_subscription_user/ $users->count()) * 100;
        $total_free_perc = ($total_free_subscription_user/ $users->count()) * 100;
        
        return view('admin.index', [
            'total_users' => $users->count(), 
            'total_subs_user' => $total_pro_subscription_user,
            'total_pro_perc' => $total_pro_perc,
            'total_free_perc' => $total_free_perc
        ]);
    }

    public function users(){
        $users = User::orderBy('id', 'desc')->get();
        foreach ($users as $key => $user) {
            if(!($user->hasRole('super_admin') || $user->hasRole('admin'))){
                $normalUsers[] = $user;
            }
        }
        return view("admin.users.index", [
            "users" => $normalUsers,
        ]); 
    }

    public function planIndex(Request $request)
    {
        $plans = PlanService::searchIndex($request->all())->paginate($this->per_page);

        return view("admin.plans.index", [
            "plans" => $plans,
            "search_params" => $request->all()
        ]);
    }

    public function createPlan(Request $request)
    {
        return view("admin.plans.create");
    }

    public function editPlan(Request $request)
    {
        $plan = Plan::find($request->id);
        if($plan){
            return response()->json([
                'status' => true,
                'data' => $plan
            ]);
        }
    }

    public function getSinglePlan(Request $request)
    {
        $plan = Plan::find($request->id);
        if($plan){
            return response()->json([
                'status' => true,
                'data' => $plan
            ]);
        }
    }

    public function storePlan(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'amount' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ]);
        }

        $plan = new Plan();
        $plan->name = $request->name;
        $plan->plan_option = $request->plan_option;
        $plan->plan_description = $request->plan_description;
        $plan->amount = $request->amount;
        $plan->plan_interval = $request->plan_interval;
        $plan->plan_interval = $request->plan_interval;
        $plan->trial_period_days = $request->trial_period_days;
        $plan->save();

        return response()->json([
            'status' => true,
            'message' => 'New Plan Added successfully'
        ]);
    }

    public function updatePlan(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ]);
        }
        $plan = Plan::find($request->id);
        $plan->name = $request->name;
        $plan->plan_option = $request->plan_option;
        $plan->plan_description = $request->plan_description;
        $plan->amount = $request->amount;
        $plan->plan_interval = $request->plan_interval;
        $plan->plan_interval = $request->plan_interval;
        $plan->trial_period_days = $request->trial_period_days;
        $plan->save();
        

        return response()->json([
            'status' => true,
            'message' => 'Plan Updated'
        ]);
    }

    public function deletePlan(Request $request)
    {
        $Plan = Plan::find($request->id);
        $status = false;
        if($Plan){
            $Plan->delete();
            $status = true;
        }

        return response()->json([
            'status' => $status,
            'message' => 'Plan deleted successfully'
        ]);

    }

    public function charlengths(Request $request){
        $charLength = CharacterLength::orderBy('id', 'desc')->get();
        return view('admin.charlengths.index', [ 
            'character_lengths' => $charLength
        ]);
    }

    public function addCharLength(Request $request){

        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ]);
        }
        
        $charLength = new CharacterLength();
        $charLength->name = $request->name;
        $charLength->save();

        return response()->json([
            'status' => true,
            'message' => 'Character length added successfully'
        ]);
    }

    public function getSingleCharLength(Request $request){
        $charLength = CharacterLength::find($request->id);
        if($charLength){
            return response()->json([
                'status' => true,
                'data' => $charLength
            ]);
        }
    }

    public function deleteCharLength(Request $request){
        $charLength = CharacterLength::find($request->id);
        $status = false;
        if($charLength){
            $charLength->delete();
            $status = true;
        }

        return response()->json([
            'status' => $status,
            'message' => 'Data deleted successfully'
        ]);
    }

    public function updateCharLength(Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ]);
        }
        $charLength = CharacterLength::find($request->id);
        $status = false;
        if($charLength){
            $charLength->name = $request->name;
            $charLength->save();
            $status = true;
        }

        return response()->json([
            'status' => $status,
            'message' => 'Character Length Type Updated'
        ]);
    }

    public function industries(Request $request){
        $industry = Industry::orderBy('id', 'desc')->get();
        return view('admin.industries.index', [ 
            'industries' => $industry
        ]);
    }

    public function addIndustries(Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ]);
        }
        
        $Industry = new Industry();
        $Industry->name = $request->name;
        $Industry->save();

        return response()->json([
            'status' => true,
            'message' => 'New Industry Added successfully'
        ]);
    }

    public function getSingleIndustries(Request $request){
        $Industry = Industry::find($request->id);
        if($Industry){
            return response()->json([
                'status' => true,
                'data' => $Industry
            ]);
        }
    }

    public function deleteIndustries(Request $request){
        $Industry = Industry::find($request->id);
        $status = false;
        if($Industry){
            $Industry->delete();
            $status = true;
        }

        return response()->json([
            'status' => $status,
            'message' => 'Data deleted successfully'
        ]);
    }

    public function updateIndustry(Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ]);
        }
        $Industry = Industry::find($request->id);
        $status = false;
        if($Industry){
            $Industry->name = $request->name;
            $Industry->save();
            $status = true;
        }
        return response()->json([
            'status' => $status,
            'message' => 'Industry Updated'
        ]);
    }
    public function intentions(Request $request){
        $intentions = Intention::orderBy('id', 'desc')->get();
        return view('admin.intentions.index', [ 
            'intentions' => $intentions
        ]);
    }

    public function addIntentions(Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ]);
        }
        
        $Intention = new Intention();
        $Intention->name = $request->name;
        $Intention->save();

        return response()->json([
            'status' => true,
            'message' => 'New Intention Added successfully'
        ]);
    }

    public function getSingleIntention(Request $request){
        $Intention = Intention::find($request->id);
        if($Intention){
            return response()->json([
                'status' => true,
                'data' => $Intention
            ]);
        }
    }

    public function deleteIntention(Request $request){
        $Intention = Intention::find($request->id);
        $status = false;
        if($Intention){
            $Intention->delete();
            $status = true;
        }

        return response()->json([
            'status' => $status,
            'message' => 'Data deleted successfully'
        ]);
    }

    public function updateIntention(Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ]);
        }
        $Intention = Intention::find($request->id);
        $status = false;
        if($Intention){
            $Intention->name = $request->name;
            $Intention->save();
            $status = true;
        }

        return response()->json([
            'status' => $status,
            'message' => 'Intention Updated'
        ]);
    }

    public function tones(Request $request){
        $tones = Tone::orderBy('id', 'desc')->get();
        return view('admin.tones.index', [ 
            'tones' => $tones
        ]);
    }

    public function addTone(Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ]);
        }
        
        $Tone = new Tone();
        $Tone->name = $request->name;
        $Tone->save();

        return response()->json([
            'status' => true,
            'message' => 'New Tone Added successfully'
        ]);
    }

    public function getSingleTone(Request $request){
        $Tone = Tone::find($request->id);
        if($Tone){
            return response()->json([
                'status' => true,
                'data' => $Tone
            ]);
        }
    }

    public function deleteTone(Request $request){
        $Tone = Tone::find($request->id);
        $status = false;
        if($Tone){
            $Tone->delete();
            $status = true;
        }

        return response()->json([
            'status' => $status,
            'message' => 'Data deleted successfully'
        ]);
    }

    public function updateTone(Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ]);
        }
        $Tone = Tone::find($request->id);
        $status = false;
        if($Tone){
            $Tone->name = $request->name;
            $Tone->save();
            $status = true;
        }

        return response()->json([
            'status' => $status,
            'message' => 'Tone Updated'
        ]);
    }

    // crowl website information related functions

    public function crowlWebsite(){
        return view('admin.crowl-website.index', [ 
            'data' => []
        ]);
    }

    public function scrape(Request $request){
        $url = $request->input('web_url');

        $client = new Client();
        $crawler = $client->request('GET', $url);

        if ($crawler->filter('title')->count() > 0) {
            $title = $crawler->filter('title')->text();
        } else {
            $title = 'Title not found';
        }
        
        if ($crawler->filter('meta[name="description"]')->count() > 0) {
            $description = $crawler->filter('meta[name="description"]')->attr('content');
        } else {
            $description = 'Description not found';
        }
        
        if ($crawler->filter('meta[name="keywords"]')->count() > 0) {
            $keywords = $crawler->filter('meta[name="keywords"]')->attr('content');
        } else {
            $keywords = 'Keywords not found';
        }

        $data = [
            'title' => $title,
            'description' => $description,
            'keywords' => $keywords,
        ];

        return response()->json([
            'status' => true,
            'data' => $data
        ]);
    }

    public function notification(Request $request)
    {
        $notifications = WebNotification::all();
        return view('admin.notifications.index', [
            'notifications' => $notifications,
            "search_params" => $request->all()
        ]);
    }

    public function addNotification(Request $request)
    {   
        $validator = Validator::make($request->all(), [
            'title' => 'required',
            'message' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ]);
        }

        $notification = new WebNotification();
        $notification->title = $request->title;
        $notification->message = $request->message;
        $notification->redirect_url = $request->redirect_url;
        $notification->save();

        return response()->json([
            'status' => true,
            'message' => 'New notification Added successfully'
        ]);
    }


}
